package com.example.datatransformer.exception;

import lombok.Getter;

@Getter
public class ErrorResponse {
    private final String errorCode;
    private final String message;
    private final long timestamp;

    public ErrorResponse(String errorCode, String message) {
        this.errorCode = errorCode;
        this.message = message;
        this.timestamp = System.currentTimeMillis();
    }
}
