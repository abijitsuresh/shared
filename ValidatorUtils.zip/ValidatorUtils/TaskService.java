package com.example.application.service;

import com.example.domainmodel.RequestModel;
import org.springframework.stereotype.Service;

/**
 * Service for processing task requests
 */
@Service
public class TaskService {

    /**
     * Process a validated task request
     *
     * @param request The validated request
     * @return Result of processing
     */
    public String processTask(RequestModel request) {
        // This is where your business logic would go
        // For this example, we'll just return a success message
        
        return "Task " + request.getTaskName() + " processed successfully for " + 
               request.getTaskData().getName();
    }
}