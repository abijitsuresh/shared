package dev.abijit.utility;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.ReadContext;
import dev.abijit.CaseModel;
import jakarta.validation.*;
import jakarta.validation.groups.Default;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class DataTransformationService {

    private final MongoTemplate mongoTemplate;
    private final ObjectMapper objectMapper;
    private final Validator validator;

    @Autowired
    public DataTransformationService(MongoTemplate mongoTemplate, ObjectMapper objectMapper) {
        this.mongoTemplate = mongoTemplate;
        this.objectMapper = objectMapper;
        
        // Initialize validator
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        this.validator = factory.getValidator();
    }

    /**
     * Transforms request data to a CaseModel using schema from MongoDB and saves it
     */
    public CaseModel transformAndSave(Map<String, Object> requestData) {
        String taskName = (String) requestData.get("taskName");
        String taskId = (String) requestData.get("taskId");
        String caseId = (String) requestData.get("caseId");
        
        // Retrieve schema from MongoDB
        SchemaDocument schemaDoc = mongoTemplate.findOne(
                Query.query(Criteria.where("taskName").is(taskName)),
                SchemaDocument.class,
                "schemas"
        );
        
        if (schemaDoc == null) {
            throw new RuntimeException("Schema not found for task: " + taskName);
        }
        
        // Create CaseModel
        CaseModel caseModel = new CaseModel();
        setProperty(caseModel, "taskId", taskId);
        setProperty(caseModel, "caseId", caseId);
        setProperty(caseModel, "taskName", taskName);
        
        // Get taskData from request
        @SuppressWarnings("unchecked")
        Map<String, Object> taskData = (Map<String, Object>) requestData.get("taskData");
        
        // Create JSON context for JsonPath operations
        ReadContext context = JsonPath.parse(taskData);
        
        // Process schema fields
        JsonNode objectModel = objectMapper.convertValue(
                schemaDoc.getFields().getDefinitions().getObjectModel(),
                JsonNode.class
        );
        
        // Process properties from schema
        processProperties(objectModel.get("properties"), context, caseModel, "");
        
        // Perform validation based on schema validation flags
        validateModel(caseModel, objectModel.get("properties"), "");
        
        // Save to MongoDB
        return mongoTemplate.save(caseModel, "cases");
    }
    
    /**
     * Validates the model based on validation flags in the schema
     */
    private void validateModel(CaseModel caseModel, JsonNode properties, String parentPath) {
        // Collect fields that require validation
        Map<String, Boolean> validationRequired = new HashMap<>();
        
        // Traverse schema to identify which fields need validation
        collectValidationRequirements(properties, validationRequired, parentPath);
        
        // Perform JSR validation on the entire object
        Set<ConstraintViolation<CaseModel>> violations = validator.validate(caseModel);
        
        // Filter violations based on validation requirements from schema
        List<ConstraintViolation<CaseModel>> relevantViolations = violations.stream()
                .filter(violation -> {
                    String propertyPath = violation.getPropertyPath().toString();
                    return validationRequired.getOrDefault(propertyPath, false);
                })
                .collect(Collectors.toList());
        
        // If there are validation errors, throw an exception
        if (!relevantViolations.isEmpty()) {
            throw new ValidationException("Validation failed: " + 
                relevantViolations.stream()
                    .map(v -> v.getPropertyPath() + ": " + v.getMessage())
                    .collect(Collectors.joining(", ")));
        }
    }
    
    /**
     * Collects validation requirements from schema
     */
    private void collectValidationRequirements(JsonNode properties, Map<String, Boolean> validationRequired, String parentPath) {
        properties.fields().forEachRemaining(entry -> {
            String fieldName = entry.getKey();
            JsonNode fieldDef = entry.getValue();
            
            String currentPath = parentPath.isEmpty() ? fieldName : parentPath + "." + fieldName;
            
            // Check if validation is required for this field
            if (fieldDef.has("validate")) {
                boolean shouldValidate = fieldDef.get("validate").asBoolean();
                validationRequired.put(currentPath, shouldValidate);
            }
            
            // Process nested object properties
            if ("object".equals(fieldDef.get("type").asText()) && fieldDef.has("properties")) {
                collectValidationRequirements(fieldDef.get("properties"), validationRequired, currentPath);
            }
            
            // Process array with object items
            if ("array".equals(fieldDef.get("type").asText()) && 
                "object".equals(fieldDef.get("valueType").asText()) && 
                fieldDef.has("properties")) {
                collectValidationRequirements(fieldDef.get("properties"), validationRequired, currentPath + "[*]");
            }
        });
    }
    
    /**
     * Process properties based on schema definition
     */
    private void processProperties(JsonNode properties, ReadContext context, CaseModel caseModel, String parentPath) {
        properties.fields().forEachRemaining(entry -> {
            String fieldName = entry.getKey();
            JsonNode fieldDef = entry.getValue();
            
            String fieldType = fieldDef.get("type").asText();
            String fieldMapping = fieldDef.has("fieldMapping") 
                    ? fieldDef.get("fieldMapping").asText() 
                    : "$." + fieldName;
            
            // Handle nested objects
            if ("object".equals(fieldType)) {
                if (fieldDef.has("properties")) {
                    String newParentPath = parentPath.isEmpty() ? fieldName : parentPath + "." + fieldName;
                    processProperties(fieldDef.get("properties"), context, caseModel, newParentPath);
                }
                
                // If field has a mapping, process it as a whole object
                if (fieldDef.has("fieldMapping")) {
                    try {
                        Object value = context.read(fieldMapping);
                        setDynamicProperty(caseModel, fieldMapping, value);
                    } catch (Exception e) {
                        // Field not found in input
                    }
                }
            } 
            // Handle arrays
            else if ("array".equals(fieldType)) {
                try {
                    List<?> values = context.read(fieldMapping);
                    
                    // If array contains objects and has properties defined
                    if ("object".equals(fieldDef.get("valueType").asText()) && fieldDef.has("properties")) {
                        // Process each object in array according to schema
                        List<Map<String, Object>> processedList = new ArrayList<>();
                        for (Object item : values) {
                            if (item instanceof Map) {
                                @SuppressWarnings("unchecked")
                                Map<String, Object> mapItem = (Map<String, Object>) item;
                                ReadContext itemContext = JsonPath.parse(mapItem);
                                Map<String, Object> processedItem = new HashMap<>();
                                
                                // Process each property of the object
                                fieldDef.get("properties").fields().forEachRemaining(propEntry -> {
                                    String propName = propEntry.getKey();
                                    JsonNode propDef = propEntry.getValue();
                                    
                                    try {
                                        Object propValue = itemContext.read("$." + propName);
                                        processedItem.put(propName, convertValue(propValue, propDef.get("type").asText()));
                                    } catch (Exception e) {
                                        // Property not found
                                    }
                                });
                                
                                processedList.add(processedItem);
                            }
                        }
                        setDynamicProperty(caseModel, fieldMapping, processedList);
                    } else {
                        // Simple array
                        setDynamicProperty(caseModel, fieldMapping, values);
                    }
                } catch (Exception e) {
                    // Field not found in input
                }
            } 
            // Handle primitive types
            else {
                try {
                    Object value = context.read(fieldMapping);
                    Object convertedValue = convertValue(value, fieldType);
                    
                    // Set the property based on the field mapping
                    setDynamicProperty(caseModel, fieldMapping, convertedValue);
                } catch (Exception e) {
                    // Field not found in input
                }
            }
        });
    }
    
    /**
     * Dynamically set a property based on the field mapping
     */
    private void setDynamicProperty(CaseModel caseModel, String fieldMapping, Object value) {
        // Extract the target field name from the JsonPath expression
        String targetPath = fieldMapping.substring(2); // Remove the "$." prefix
        
        // Handle nested properties
        String[] parts = targetPath.split("\\.");
        if (parts.length == 1) {
            // Direct property
            setProperty(caseModel, parts[0], value);
        } else {
            // Nested property
            Map<String, Object> currentMap = null;
            String rootProperty = parts[0];
            
            // Get or create the root map
            Object rootObj = getProperty(caseModel, rootProperty);
            if (rootObj instanceof Map) {
                @SuppressWarnings("unchecked")
                Map<String, Object> rootMap = (Map<String, Object>) rootObj;
                currentMap = rootMap;
            } else {
                currentMap = new HashMap<>();
                setProperty(caseModel, rootProperty, currentMap);
            }
            
            // Navigate through the nested structure
            for (int i = 1; i < parts.length - 1; i++) {
                String part = parts[i];
                Object nextObj = currentMap.get(part);
                
                if (nextObj instanceof Map) {
                    @SuppressWarnings("unchecked")
                    Map<String, Object> nextMap = (Map<String, Object>) nextObj;
                    currentMap = nextMap;
                } else {
                    Map<String, Object> nextMap = new HashMap<>();
                    currentMap.put(part, nextMap);
                    currentMap = nextMap;
                }
            }
            
            // Set the final property
            currentMap.put(parts[parts.length - 1], value);
        }
    }
    
    /**
     * Convert a value to the specified type
     */
    private Object convertValue(Object value, String type) {
        if (value == null) return null;
        
        return switch (type) {
            case "String" -> value.toString();
            case "Int32" -> value instanceof Number ? ((Number) value).intValue() : Integer.parseInt(value.toString());
            case "LocalDateTime" -> value instanceof LocalDateTime ? value : LocalDateTime.parse(value.toString());
            default -> value;
        };
    }
    
    /**
     * Use reflection to set a property on an object
     */
    private void setProperty(Object obj, String propertyName, Object value) {
        try {
            // Generate setter method name
            String setterName = "set" + propertyName.substring(0, 1).toUpperCase() + propertyName.substring(1);
            
            // Try to find the setter method
            Method[] methods = obj.getClass().getMethods();
            for (Method method : methods) {
                if (method.getName().equals(setterName) && method.getParameterCount() == 1) {
                    Class<?> paramType = method.getParameterTypes()[0];
                    
                    // Convert value to the correct type if needed
                    Object convertedValue = value;
                    if (value != null && !paramType.isAssignableFrom(value.getClass())) {
                        if (paramType == int.class || paramType == Integer.class) {
                            convertedValue = value instanceof Number ? ((Number) value).intValue() : Integer.parseInt(value.toString());
                        } else if (paramType == LocalDateTime.class) {
                            convertedValue = value instanceof LocalDateTime ? value : LocalDateTime.parse(value.toString());
                        }
                        // Add more type conversions as needed
                    }
                    
                    method.invoke(obj, convertedValue);
                    return;
                }
            }
            
            // If setter not found, try direct field access
            Field field = findField(obj.getClass(), propertyName);
            if (field != null) {
                field.setAccessible(true);
                field.set(obj, value);
            }
        } catch (Exception e) {
            throw new RuntimeException("Error setting property: " + propertyName, e);
        }
    }
    
    /**
     * Use reflection to get a property from an object
     */
    private Object getProperty(Object obj, String propertyName) {
        try {
            // Generate getter method name
            String getterName = "get" + propertyName.substring(0, 1).toUpperCase() + propertyName.substring(1);
            
            // Try to find the getter method
            Method[] methods = obj.getClass().getMethods();
            for (Method method : methods) {
                if (method.getName().equals(getterName) && method.getParameterCount() == 0) {
                    return method.invoke(obj);
                }
            }
            
            // If getter not found, try direct field access
            Field field = findField(obj.getClass(), propertyName);
            if (field != null) {
                field.setAccessible(true);
                return field.get(obj);
            }
            
            return null;
        } catch (Exception e) {
            throw new RuntimeException("Error getting property: " + propertyName, e);
        }
    }
    
    /**
     * Find a field in a class or its superclasses
     */
    private Field findField(Class<?> clazz, String fieldName) {
        try {
            return clazz.getDeclaredField(fieldName);
        } catch (NoSuchFieldException e) {
            Class<?> superClass = clazz.getSuperclass();
            if (superClass != null) {
                return findField(superClass, fieldName);
            }
            return null;
        }
    }
    
    /**
     * Convert a CaseModel back to the original request format
     */
    public Map<String, Object> convertToOriginalFormat(CaseModel caseModel) {
        // Get schema for this task
        SchemaDocument schemaDoc = mongoTemplate.findOne(
                Query.query(Criteria.where("taskName").is(caseModel.getTaskName())),
                SchemaDocument.class,
                "schemas"
        );
        
        if (schemaDoc == null) {
            throw new RuntimeException("Schema not found for task: " + caseModel.getTaskName());
        }
        
        // Create result object
        Map<String, Object> result = new HashMap<>();
        result.put("taskId", getProperty(caseModel, "taskId"));
        result.put("caseId", getProperty(caseModel, "caseId"));
        result.put("taskName", getProperty(caseModel, "taskName"));
        
        // Create taskData object
        Map<String, Object> taskData = new HashMap<>();
        result.put("taskData", taskData);
        
        // Get object model from schema
        JsonNode objectModel = objectMapper.convertValue(
                schemaDoc.getFields().getDefinitions().getObjectModel(),
                JsonNode.class
        );
        
        // Convert CaseModel to original format based on schema
        convertToOriginalFormat(objectModel.get("properties"), caseModel, taskData);
        
        return result;
    }
    
    /**
     * Convert CaseModel properties back to the original format based on schema
     */
    private void convertToOriginalFormat(JsonNode properties, CaseModel caseModel, Map<String, Object> taskData) {
        properties.fields().forEachRemaining(entry -> {
            String fieldName = entry.getKey();
            JsonNode fieldDef = entry.getValue();
            
            String fieldType = fieldDef.get("type").asText();
            String fieldMapping = fieldDef.has("fieldMapping") 
                    ? fieldDef.get("fieldMapping").asText().substring(2) // Remove $. prefix
                    : fieldName;
            
            // Handle different field types
            if ("object".equals(fieldType)) {
                if (fieldDef.has("properties")) {
                    Object value = getDynamicProperty(caseModel, fieldMapping);
                    if (value != null) {
                        Map<String, Object> nestedObject = new HashMap<>();
                        setNestedPathValue(taskData, fieldName, nestedObject);
                        
                        // Process nested object properties
                        if (value instanceof Map) {
                            @SuppressWarnings("unchecked")
                            Map<String, Object> valueMap = (Map<String, Object>) value;
                            fieldDef.get("properties").fields().forEachRemaining(propEntry -> {
                                String propName = propEntry.getKey();
                                JsonNode propDef = propEntry.getValue();
                                
                                String propMapping = propDef.has("fieldMapping") 
                                        ? propDef.get("fieldMapping").asText().substring(2)
                                        : propName;
                                
                                Object propValue = valueMap.get(propMapping);
                                if (propValue != null) {
                                    nestedObject.put(propName, propValue);
                                }
                            });
                        }
                    }
                } else {
                    Object value = getDynamicProperty(caseModel, fieldMapping);
                    if (value != null) {
                        setNestedPathValue(taskData, fieldName, value);
                    }
                }
            } else if ("array".equals(fieldType)) {
                Object value = getDynamicProperty(caseModel, fieldMapping);
                if (value != null && value instanceof List) {
                    setNestedPathValue(taskData, fieldName, value);
                }
            } else {
                // Handle primitive types
                Object value = getDynamicProperty(caseModel, fieldMapping);
                if (value != null) {
                    setNestedPathValue(taskData, fieldName, value);
                }
            }
        });
    }
    
    /**
     * Dynamically get a property from CaseModel based on path
     */
    private Object getDynamicProperty(CaseModel caseModel, String propertyPath) {
        String[] parts = propertyPath.split("\\.");
        
        if (parts.length == 1) {
            // Direct property
            return getProperty(caseModel, parts[0]);
        } else {
            // Nested property
            Object current = getProperty(caseModel, parts[0]);
            
            // Navigate through the nested structure
            for (int i = 1; i < parts.length; i++) {
                if (current == null) {
                    return null;
                }
                
                if (current instanceof Map) {
                    @SuppressWarnings("unchecked")
                    Map<String, Object> map = (Map<String, Object>) current;
                    current = map.get(parts[i]);
                } else {
                    // If not a map, try to get property via reflection
                    current = getProperty(current, parts[i]);
                }
            }
            
            return current;
        }
    }
    
    /**
     * Set a value in a nested path within a map
     */
    private void setNestedPathValue(Map<String, Object> map, String path, Object value) {
        String[] parts = path.split("\\.");
        
        Map<String, Object> current = map;
        for (int i = 0; i < parts.length - 1; i++) {
            String part = parts[i];
            Object next = current.get(part);
            
            if (!(next instanceof Map)) {
                next = new HashMap<String, Object>();
                current.put(part, next);
            }
            
            @SuppressWarnings("unchecked")
            Map<String, Object> nextMap = (Map<String, Object>) next;
            current = nextMap;
        }
        
        current.put(parts[parts.length - 1], value);
    }
}