package com.example.datatransformer.model;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class StringField {
    @NotBlank(groups = RequiredGroup.class)
    private String value;

    public StringField(String value) {
        this.value = value;
    }

    // Validation groups
    public interface RequiredGroup {}
}
