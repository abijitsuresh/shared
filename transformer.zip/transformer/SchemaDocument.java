class SchemaDocument {
    private String taskName;
    private String modelClassName;
    private SchemaFields fields;
    
    // Getters and setters
    public String getTaskName() { return taskName; }
    public void setTaskName(String taskName) { this.taskName = taskName; }
    
    public String getModelClassName() { return modelClassName; }
    public void setModelClassName(String modelClassName) { this.modelClassName = modelClassName; }
    
    public SchemaFields getFields() { return fields; }
    public void setFields(SchemaFields fields) { this.fields = fields; }
}

class SchemaFields {
    private SchemaDefinitions definitions;
    
    // Getters and setters
    public SchemaDefinitions getDefinitions() { return definitions; }
    public void setDefinitions(SchemaDefinitions definitions) { this.definitions = definitions; }
}

class SchemaDefinitions {
    private JsonNode objectModel;
    
    // Getters and setters
    public JsonNode getObjectModel() { return objectModel; }
    public void setObjectModel(JsonNode objectModel) { this.objectModel = objectModel; }
}

/**
 * Custom validation exception
 */
class ValidationException extends RuntimeException {
    public ValidationException(String message) {
        super(message);
    }
}
