package com.example.datatransformer.service;

import com.example.datatransformer.exception.TransformationException;
import com.example.datatransformer.model.ObjectSchema;
import com.example.datatransformer.model.PropertySchema;
import com.example.datatransformer.model.SchemaDefinition;
import com.example.datatransformer.model.TaskRequest;
import com.example.datatransformer.repository.SchemaRepository;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
@Slf4j
@RequiredArgsConstructor
public class ReverseTransformerService1 {
    private final SchemaRepository schemaRepository;
    private final ObjectMapper objectMapper;

    /**
     * Reverse transforms the data based on schema mappings.
     * Takes a transformed object and creates a compact TaskRequest object.
     *
     * @param expandedData The expanded data to reverse transform
     * @return TaskRequest object with the original structure
     */
    public TaskRequest reverseTransform(JsonNode expandedData) {
        try {
            String taskName = expandedData.path("taskName").asText();
            if (taskName.isEmpty()) {
                throw new TransformationException("taskName is required in the input data");
            }

            // Get schema from MongoDB repository
            SchemaDefinition schema = schemaRepository.findByTaskName(taskName)
                    .orElseThrow(() -> new TransformationException("Schema not found for task: " + taskName));

            // Create output TaskRequest
            TaskRequest result = new TaskRequest();
            result.setTaskName(taskName);

            // Create taskData object
            ObjectNode taskData = objectMapper.createObjectNode();

            // Process schema and build the compact taskData
            reverseTransformObject(schema.getFields().getDefinitions().getObjectModel(), expandedData, taskData);

            // Set the taskData
            result.setTaskData(objectMapper.convertValue(taskData, Map.class));

            return result;
        } catch (Exception e) {
            throw new TransformationException("Error reverse transforming data: " + e.getMessage(), e);
        }
    }

    /**
     * Reverse transforms an object based on schema.
     */
    private void reverseTransformObject(ObjectSchema schema, JsonNode sourceData, ObjectNode targetNode) {
        if (schema == null || schema.getProperties() == null) {
            return;
        }

        // Create map of properties with field mappings for faster lookup
        Map<String, String> fieldMappingsByTarget = new HashMap<>();
        Map<String, PropertySchema> propertiesByPath = new HashMap<>();
        buildFieldMappingMap(schema.getProperties(), "", fieldMappingsByTarget, propertiesByPath);

        // Process each property in the schema
        schema.getProperties().forEach((propertyName, propertySchema) -> {
            // Check if the property is directly available in source data
            JsonNode valueNode = sourceData.path(propertyName);

            if (!valueNode.isMissingNode()) {
                // Direct property found, add to target
                addValueToTarget(targetNode, propertyName, valueNode, propertySchema);
            }

            // Check if property has a field mapping that might be found elsewhere
            if (propertySchema.getFieldMapping() != null) {
                String mappingPath = propertySchema.getFieldMapping().replace("$.", "");
                JsonNode mappedValue = findValueByPath(sourceData, mappingPath);

                if (!mappedValue.isMissingNode()) {
                    // Found value through field mapping, add to target
                    addValueToTarget(targetNode, propertyName, mappedValue, propertySchema);
                }
            }

            // Handle nested objects
            if ("object".equals(propertySchema.getType()) && propertySchema.getProperties() != null) {
                // Create a new ObjectSchema for the nested properties
                ObjectSchema nestedSchema = new ObjectSchema();
                nestedSchema.setProperties(propertySchema.getProperties());
                nestedSchema.setType("object");
                nestedSchema.setValidate(propertySchema.getValidate());

                // Look for direct object in source
                JsonNode directObject = sourceData.path(propertyName);

                // Also check if it might be found through field mapping
                JsonNode mappedObject = null;
                if (propertySchema.getFieldMapping() != null) {
                    String mappingPath = propertySchema.getFieldMapping().replace("$.", "");
                    mappedObject = findValueByPath(sourceData, mappingPath);
                }

                // Use either the direct object or the mapped object if available
                JsonNode sourceObject = !directObject.isMissingNode() ? directObject :
                        (mappedObject != null && !mappedObject.isMissingNode() ? mappedObject : null);

                if (sourceObject != null && sourceObject.isObject()) {
                    // Create the nested object in target if not exists
                    if (!targetNode.has(propertyName)) {
                        targetNode.set(propertyName, objectMapper.createObjectNode());
                    }

                    // Process the nested object recursively
                    reverseTransformObject(nestedSchema, sourceObject, (ObjectNode) targetNode.get(propertyName));
                }
            }

            // Handle arrays
            if ("array".equals(propertySchema.getType())) {
                // Look for direct array in source
                JsonNode directArray = sourceData.path(propertyName);

                // Also check if it might be found through field mapping
                JsonNode mappedArray = null;
                if (propertySchema.getFieldMapping() != null) {
                    String mappingPath = propertySchema.getFieldMapping().replace("$.", "");
                    mappedArray = findValueByPath(sourceData, mappingPath);
                }

                // Use either the direct array or the mapped array if available
                JsonNode sourceArray = !directArray.isMissingNode() ? directArray :
                        (!mappedArray.isMissingNode() ? mappedArray : null);

                if (sourceArray != null && sourceArray.isArray()) {
                    // Create array in target
                    ArrayNode targetArray = targetNode.putArray(propertyName);

                    // Process each array item
                    for (JsonNode item : sourceArray) {
                        if ("object".equals(propertySchema.getValueType()) && propertySchema.getProperties() != null) {
                            // Create nested object schema for array items
                            ObjectSchema itemSchema = new ObjectSchema();
                            itemSchema.setProperties(propertySchema.getProperties());
                            itemSchema.setType("object");
                            itemSchema.setValidate(propertySchema.getValidate());

                            // Add object to array and process recursively
                            ObjectNode targetItem = targetArray.addObject();
                            reverseTransformObject(itemSchema, item, targetItem);
                        } else {
                            // For primitive array items, add directly
                            addValueToArrayNode(targetArray, item);
                        }
                    }
                }
            }
        });
    }

    /**
     * Builds a map of field mappings for faster lookup.
     */
    private void buildFieldMappingMap(
            Map<String, PropertySchema> properties,
            String parentPath,
            Map<String, String> fieldMappingsByTarget,
            Map<String, PropertySchema> propertiesByPath) {

        if (properties == null) {
            return;
        }

        properties.forEach((propertyName, propertySchema) -> {
            String currentPath = parentPath.isEmpty() ? propertyName : parentPath + "." + propertyName;

            // Add property to path map
            propertiesByPath.put(currentPath, propertySchema);

            // Add field mapping if exists
            if (propertySchema.getFieldMapping() != null) {
                String targetPath = propertySchema.getFieldMapping().replace("$.", "");
                fieldMappingsByTarget.put(targetPath, currentPath);
            }

            // Process nested properties if object
            if ("object".equals(propertySchema.getType()) && propertySchema.getProperties() != null) {
                buildFieldMappingMap(propertySchema.getProperties(), currentPath, fieldMappingsByTarget, propertiesByPath);
            }

            // Process array item properties if array of objects
            if ("array".equals(propertySchema.getType()) && "object".equals(propertySchema.getValueType()) &&
                    propertySchema.getProperties() != null) {
                buildFieldMappingMap(propertySchema.getProperties(), currentPath + "[]", fieldMappingsByTarget, propertiesByPath);
            }
        });
    }

    /**
     * Finds a value in a JSON node by path.
     */
    private JsonNode findValueByPath(JsonNode node, String path) {
        if (path == null || path.isEmpty()) {
            return node;
        }

        String[] parts = path.split("\\.");
        JsonNode current = node;

        for (String part : parts) {
            current = current.path(part);
            if (current.isMissingNode()) {
                return current;
            }
        }

        return current;
    }

    /**
     * Adds a value to a target node based on schema type.
     */
    private void addValueToTarget(ObjectNode targetNode, String propertyName, JsonNode valueNode, PropertySchema schema) {
        if (valueNode == null || valueNode.isMissingNode()) {
            return;
        }

        switch (schema.getType()) {
            case "String" -> {
                if (valueNode.isTextual()) {
                    targetNode.put(propertyName, valueNode.asText());
                } else {
                    targetNode.put(propertyName, valueNode.toString());
                }
            }
            case "Int32" -> {
                if (valueNode.isInt()) {
                    targetNode.put(propertyName, valueNode.asInt());
                } else if (valueNode.isTextual()) {
                    try {
                        targetNode.put(propertyName, Integer.parseInt(valueNode.asText()));
                    } catch (NumberFormatException e) {
                        log.warn("Failed to parse Int32 value for {}: {}", propertyName, valueNode.asText());
                    }
                }
            }
            case "LocalDateTime" -> {
                if (valueNode.isTextual()) {
                    targetNode.put(propertyName, valueNode.asText());
                }
            }
            case "object" -> {
                if (valueNode.isObject()) {
                    targetNode.set(propertyName, valueNode);
                }
            }
            case "array" -> {
                if (valueNode.isArray()) {
                    targetNode.set(propertyName, valueNode);
                }
            }
            default -> targetNode.set(propertyName, valueNode);
        }
    }

    /**
     * Adds a value to an array node.
     */
    private void addValueToArrayNode(ArrayNode arrayNode, JsonNode value) {
        if (value.isTextual()) {
            arrayNode.add(value.asText());
        } else if (value.isInt()) {
            arrayNode.add(value.asInt());
        } else if (value.isLong()) {
            arrayNode.add(value.asLong());
        } else if (value.isDouble()) {
            arrayNode.add(value.asDouble());
        } else if (value.isBoolean()) {
            arrayNode.add(value.asBoolean());
        } else if (value.isObject()) {
            arrayNode.add(value);
        } else if (value.isArray()) {
            arrayNode.add(value);
        } else {
            arrayNode.add(value);
        }
    }
}