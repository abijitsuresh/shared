package com.example.datatransformer.service;

import com.example.datatransformer.model.ObjectSchema;
import com.example.datatransformer.model.PropertySchema;
import com.example.datatransformer.model.SchemaDefinition;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import lombok.extern.slf4j.Slf4j;

import java.util.*;

@Slf4j
public class SchemaValidator {

    private final ObjectMapper objectMapper = new ObjectMapper()
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    private final Validator validator;

    public SchemaValidator() {
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();
    }

    /**
     * Validates a Map against a schema, focusing only on fields where "validate" is true.
     *
     * @param data The data Map to validate
     * @param schema The schema object containing validation rules
     * @return A list of validation errors
     */
    public List<String> validateAgainstSchema(Map<String, Object> data, SchemaDefinition schema) {
        List<String> validationErrors = new ArrayList<>();

        try {
            // Apply field mappings according to the schema
            Map<String, Object> transformedData = applyFieldMappings(data, schema);

            // Convert the data map to the target model class
            String modelClassName = schema.getTaskModelClassName();
            Class<?> modelClass = Class.forName(modelClassName);

            // Use ObjectMapper to convert the Map to the target model object
            Object modelInstance = objectMapper.convertValue(transformedData, modelClass);

            // Apply jakarta validation on the model
            Set<ConstraintViolation<Object>> violations = validator.validate(modelInstance);

            // Filter violations to only include fields marked with "validate": true in the schema
            for (ConstraintViolation<Object> violation : violations) {
                String propertyPath = violation.getPropertyPath().toString();
                if (isFieldValidatable(propertyPath, schema.getFields().getDefinitions().getObjectModel())) {
                    validationErrors.add(propertyPath + ": " + violation.getMessage());
                }
            }

        } catch (Exception e) {
            validationErrors.add("Validation error: " + e.getMessage());
            log.error("Exception occurred:", e);
        }

        return validationErrors;
    }

    /**
     * Applies field mappings according to the schema
     */
    private Map<String, Object> applyFieldMappings(Map<String, Object> inputData, SchemaDefinition schema) {
        // Convert input data to JSON for JsonPath operations
        String jsonData = null;
        try {
            jsonData = objectMapper.writeValueAsString(inputData);
        } catch (Exception e) {
            throw new RuntimeException("Failed to convert input data to JSON", e);
        }

        DocumentContext context = JsonPath.parse(jsonData);

        // Create a new map for transformed data
        Map<String, Object> transformedData = new HashMap<>();

        // Process all fields using the schema
        processFieldMappings(transformedData, "", context,
                schema.getFields().getDefinitions().getObjectModel().getProperties());

        return transformedData;
    }

    /**
     * Recursively processes field mappings
     */
    private void processFieldMappings(Map<String, Object> target, String basePath,
                                      DocumentContext context, Map<String, PropertySchema> properties) {

        for (Map.Entry<String, PropertySchema> entry : properties.entrySet()) {
            String fieldName = entry.getKey();
            PropertySchema prop = entry.getValue();
            String currentPath = basePath.isEmpty() ? fieldName : basePath + "." + fieldName;

            String sourceMapping = prop.getFieldMapping();
            String jsonPath = sourceMapping != null ? sourceMapping : "$." + currentPath;

            try {
                // Get value from source data using JsonPath
                Object value = context.read(jsonPath);

                if ("object".equals(prop.getType()) && prop.getProperties() != null) {
                    // For objects, create a nested map and process recursively
                    Map<String, Object> nestedMap = new HashMap<>();
                    target.put(fieldName, nestedMap);

                    if (sourceMapping != null) {
                        // If this object has a field mapping, we need to read it first
                        String nestedJson = objectMapper.writeValueAsString(value);
                        DocumentContext nestedContext = JsonPath.parse(nestedJson);
                        processFieldMappings(nestedMap, "", nestedContext, prop.getProperties());
                    } else {
                        // Otherwise, continue with the current context
                        processFieldMappings(nestedMap, currentPath, context, prop.getProperties());
                    }
                } else if ("array".equals(prop.getType())) {
                    // Handle arrays
                    if (value instanceof List) {
                        if ("object".equals(prop.getValueType()) && prop.getProperties() != null) {
                            // For arrays of objects, process each item
                            List<Object> sourceList = (List<Object>) value;
                            List<Map<String, Object>> targetList = new ArrayList<>();

                            for (Object item : sourceList) {
                                Map<String, Object> mappedItem = new HashMap<>();
                                String itemJson = objectMapper.writeValueAsString(item);
                                DocumentContext itemContext = JsonPath.parse(itemJson);

                                // Process each property of the object in the array
                                for (Map.Entry<String, PropertySchema> propEntry : prop.getProperties().entrySet()) {
                                    String propName = propEntry.getKey();
                                    PropertySchema propDef = propEntry.getValue();

                                    String propMapping = propDef.getFieldMapping();
                                    String propPath = propMapping != null ? propMapping : "$." + propName;

                                    try {
                                        Object propValue = itemContext.read(propPath);
                                        mappedItem.put(propName, propValue);
                                    } catch (Exception e) {
                                        // Property not found, skip
                                    }
                                }

                                targetList.add(mappedItem);
                            }

                            target.put(fieldName, targetList);
                        } else {
                            // For primitive arrays, just copy the value
                            target.put(fieldName, value);
                        }
                    }
                } else {
                    // For primitive types, just copy the value
                    target.put(fieldName, value);
                }
            } catch (Exception e) {
                // Field not found in source data or other error, skip
            }
        }
    }

    /**
     * Determines if a field should be validated based on the schema
     */
    private boolean isFieldValidatable(String propertyPath, ObjectSchema objectModel) {
        Map<String, PropertySchema> properties = objectModel.getProperties();
        String[] pathParts = propertyPath.split("\\.");

        Map<String, PropertySchema> currentNode = properties;
        for (int i = 0; i < pathParts.length; i++) {
            String part = pathParts[i];

            // Handle array indices
            if (part.matches("\\d+")) {
                // Skip array indices
                continue;
            }

            if (!currentNode.containsKey(part)) {
                return false;
            }

            PropertySchema field = currentNode.get(part);

            // If we're at the leaf node, check validate flag
            if (i == pathParts.length - 1) {
                return field.getValidate();
            }

            // Move to next level in the path
            if ("object".equals(field.getType()) && field.getProperties() != null) {
                currentNode = field.getProperties();
            } else if ("array".equals(field.getType()) && "object".equals(field.getValueType()) && field.getProperties() != null) {
                currentNode = field.getProperties();
            } else {
                return false;
            }
        }

        return false;
    }
}
