package com.example.sharedservice.validation;

import org.springframework.expression.Expression;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.util.*;

/**
 * Utility class to validate request objects against a schema definition.
 */
public class RequestValidatorUtils {

    private static final ExpressionParser expressionParser = new SpelExpressionParser();

    /**
     * Validates a request object against its schema definition
     *
     * @param request The request object to validate
     * @param schema The schema definition
     * @return A list of validation errors, empty if validation passes
     */
    public static List<String> validate(Object request, Object schema) {
        List<String> errors = new ArrayList<>();
        
        if (request == null || schema == null) {
            errors.add("Request and schema cannot be null");
            return errors;
        }
        
        Map<String, Object> requestMap = convertToMap(request);
        Map<String, Object> schemaMap = convertToMap(schema);
        
        // Extract the object model from schema
        Map<String, Object> objectModel = getObjectModel(schemaMap);
        if (objectModel == null) {
            errors.add("Invalid schema: objectModel not found");
            return errors;
        }
        
        // Extract the taskData from request
        Map<String, Object> taskData = (Map<String, Object>) requestMap.get("taskData");
        if (taskData == null) {
            errors.add("Invalid request: taskData not found");
            return errors;
        }
        
        // Validate the request against the schema
        validateObject(taskData, objectModel, "", errors, taskData);
        
        return errors;
    }
    
    /**
     * Recursively validate an object against its schema definition
     */
    private static void validateObject(Map<String, Object> requestObj, Map<String, Object> schemaObj, 
                                     String path, List<String> errors, Map<String, Object> rootObj) {
        Map<String, Object> properties = (Map<String, Object>) schemaObj.get("properties");
        if (properties == null) {
            return;
        }
        
        for (Map.Entry<String, Object> entry : properties.entrySet()) {
            String fieldName = entry.getKey();
            Map<String, Object> fieldSchema = (Map<String, Object>) entry.getValue();
            
            // Get current path for error messages
            String currentPath = path.isEmpty() ? fieldName : path + "." + fieldName;
            
            // Skip validation if validate flag is false
            Boolean validateField = (Boolean) fieldSchema.getOrDefault("validate", false);
            if (validateField != null && !validateField) {
                continue;
            }
            
            Object fieldValue = requestObj.get(fieldName);
            
            // Check the field type
            String fieldType = (String) fieldSchema.get("type");
            if (fieldType == null) {
                continue;
            }
            
            // Get validation details if present
            Map<String, Object> validation = (Map<String, Object>) fieldSchema.get("validation");
            
            if (validation != null) {
                String requirementType = (String) validation.get("requirementType");
                
                if ("REQUIRED".equals(requirementType)) {
                    validateRequired(fieldValue, fieldType, currentPath, errors);
                } else if ("CONDITIONAL".equals(requirementType)) {
                    String condition = (String) validation.get("condition");
                    if (condition != null) {
                        validateConditional(fieldValue, condition, currentPath, validation, rootObj, errors);
                    }
                }
                
                // Validate field length if specified
                if (fieldValue != null) {
                    validateFieldTypeParams(fieldValue, validation, currentPath, errors);
                }
            }
            
            // Recursively validate nested objects
            if ("object".equals(fieldType) && fieldValue != null) {
                validateObject((Map<String, Object>) fieldValue, fieldSchema, currentPath, errors, rootObj);
            }
            
            // Validate arrays
            if ("array".equals(fieldType) && fieldValue != null) {
                validateArray(fieldValue, fieldSchema, currentPath, errors, rootObj);
            }
        }
    }
    
    /**
     * Validate array fields
     */
    private static void validateArray(Object fieldValue, Map<String, Object> fieldSchema, 
                                     String path, List<String> errors, Map<String, Object> rootObj) {
        if (!(fieldValue instanceof List)) {
            errors.add(path + ": Expected an array");
            return;
        }
        
        List<?> arrayValue = (List<?>) fieldValue;
        Map<String, Object> validation = (Map<String, Object>) fieldSchema.get("validation");
        
        // Check if array is required and empty
        if (validation != null && "REQUIRED".equals(validation.get("requirementType")) && CollectionUtils.isEmpty(arrayValue)) {
            errors.add(path + ": " + validation.getOrDefault("errorMessage", "Field is required"));
            return;
        }
        
        // If array contains objects, validate each object
        String valueType = (String) fieldSchema.get("valueType");
        if ("object".equals(valueType)) {
            Map<String, Object> itemProperties = (Map<String, Object>) fieldSchema.get("properties");
            if (itemProperties != null) {
                for (int i = 0; i < arrayValue.size(); i++) {
                    Object item = arrayValue.get(i);
                    if (item instanceof Map) {
                        validateArrayItem((Map<String, Object>) item, itemProperties, path + "[" + i + "]", errors, rootObj);
                    }
                }
            }
        }
    }
    
    /**
     * Validate individual array items
     */
    private static void validateArrayItem(Map<String, Object> item, Map<String, Object> itemProperties, 
                                         String path, List<String> errors, Map<String, Object> rootObj) {
        for (Map.Entry<String, Object> entry : itemProperties.entrySet()) {
            String fieldName = entry.getKey();
            Object fieldSchema = entry.getValue();
            
            if (fieldSchema instanceof Map) {
                Map<String, Object> fieldSchemaMap = (Map<String, Object>) fieldSchema;
                Boolean validateField = (Boolean) fieldSchemaMap.getOrDefault("validate", false);
                if (validateField != null && validateField) {
                    Object fieldValue = item.get(fieldName);
                    String currentPath = path + "." + fieldName;
                    
                    // For array items, the validation might be directly in the field schema
                    String requirementType = (String) fieldSchemaMap.get("requirementType");
                    
                    if ("REQUIRED".equals(requirementType)) {
                        validateRequired(fieldValue, "String", currentPath, errors);
                    } else if ("CONDITIONAL".equals(requirementType)) {
                        String condition = (String) fieldSchemaMap.get("condition");
                        if (condition != null) {
                            validateConditional(fieldValue, condition, currentPath, fieldSchemaMap, item, errors);
                        }
                    }
                    
                    // Validate field length if specified
                    if (fieldValue != null) {
                        validateFieldTypeParams(fieldValue, fieldSchemaMap, currentPath, errors);
                    }
                }
            }
        }
    }
    
    /**
     * Validate required fields
     */
    private static void validateRequired(Object fieldValue, String fieldType, String path, List<String> errors) {
        if (fieldValue == null) {
            errors.add(path + ": Field is required");
        } else if ("String".equals(fieldType) && !StringUtils.hasText(fieldValue.toString())) {
            errors.add(path + ": Field cannot be empty");
        } else if ("array".equals(fieldType) && fieldValue instanceof List && ((List<?>) fieldValue).isEmpty()) {
            errors.add(path + ": Array cannot be empty");
        }
    }
    
    /**
     * Validate conditional fields using SpEL
     */
    private static void validateConditional(Object fieldValue, String condition, String path, 
                                          Map<String, Object> validation, Map<String, Object> rootObj, 
                                          List<String> errors) {
        try {
            Expression expression = expressionParser.parseExpression(condition);
            StandardEvaluationContext context = new StandardEvaluationContext(rootObj);
            Boolean result = expression.getValue(context, Boolean.class);
            
            if (Boolean.TRUE.equals(result)) {
                String errorMessage = (String) validation.getOrDefault("errorMessage", "Conditional validation failed");
                
                if (fieldValue == null) {
                    errors.add(path + ": " + errorMessage);
                } else if (validation.get("fieldType") != null && "STRING".equals(validation.get("fieldType")) && 
                          !StringUtils.hasText(fieldValue.toString())) {
                    errors.add(path + ": " + errorMessage);
                }
            }
        } catch (Exception e) {
            errors.add(path + ": Error evaluating condition: " + e.getMessage());
        }
    }
    
    /**
     * Validate field type parameters (e.g., min/maxLength)
     */
    private static void validateFieldTypeParams(Object fieldValue, Map<String, Object> validation, 
                                              String path, List<String> errors) {
        if (validation == null) {
            return;
        }
        
        Map<String, Object> typeParams = (Map<String, Object>) validation.get("typeValidationParams");
        if (typeParams == null) {
            return;
        }
        
        String fieldType = (String) validation.get("fieldType");
        
        if ("STRING".equals(fieldType) && fieldValue instanceof String) {
            String stringValue = (String) fieldValue;
            
            if (typeParams.containsKey("minLength")) {
                Integer minLength = (Integer) typeParams.get("minLength");
                if (minLength != null && stringValue.length() < minLength) {
                    errors.add(path + ": Must be at least " + minLength + " characters");
                }
            }
            
            if (typeParams.containsKey("maxLength")) {
                Integer maxLength = (Integer) typeParams.get("maxLength");
                if (maxLength != null && stringValue.length() > maxLength) {
                    errors.add(path + ": Must be at most " + maxLength + " characters");
                }
            }
        } else if ("LOCAL_DATE_TIME".equals(fieldType)) {
            // Validate date format if needed
            if (!(fieldValue instanceof LocalDateTime || fieldValue instanceof String)) {
                errors.add(path + ": Invalid date format");
            }
        }
    }
    
    /**
     * Extract the objectModel from the schema
     */
    private static Map<String, Object> getObjectModel(Map<String, Object> schema) {
        try {
            Map<String, Object> fields = (Map<String, Object>) schema.get("fields");
            Map<String, Object> definitions = (Map<String, Object>) fields.get("definitions");
            return (Map<String, Object>) definitions.get("objectModel");
        } catch (Exception e) {
            return null;
        }
    }
    
    /**
     * Convert an object to a Map for easier access
     */
    @SuppressWarnings("unchecked")
    private static Map<String, Object> convertToMap(Object obj) {
        if (obj instanceof Map) {
            return (Map<String, Object>) obj;
        }
        
        // Here you would use ObjectMapper or similar to convert Java object to Map
        // For simplicity, we'll assume obj is already a Map
        return Collections.emptyMap();
    }
}