package com.example.datatransformer.service;

import com.example.datatransformer.exception.TransformationException;
import com.example.datatransformer.model.ObjectSchema;
import com.example.datatransformer.model.PropertySchema;
import com.example.datatransformer.model.SchemaDefinition;
import com.example.datatransformer.model.TaskRequest;
import com.example.datatransformer.repository.SchemaRepository;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.Option;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Service
@Slf4j
@RequiredArgsConstructor
public class DataTransformerService0 {
    private final SchemaRepository schemaRepository;
    private final ObjectMapper objectMapper;
    private final Validator validator;

    private static final Configuration JSON_PATH_CONFIG = Configuration.builder()
            .options(Option.DEFAULT_PATH_LEAF_TO_NULL)
            .build();

    public JsonNode transformData(TaskRequest request) {
        try {
            // Get schema from MongoDB repository
            SchemaDefinition schema = schemaRepository.findByTaskName(request.getTaskName())
                    .orElseThrow(() -> new TransformationException("Schema not found for task: " + request.getTaskName()));

            // Convert input request to JsonNode
            JsonNode taskData = objectMapper.valueToTree(request.getTaskData());

            // Create output object with taskName
            ObjectNode result = objectMapper.createObjectNode();
            result.put("taskName", request.getTaskName());

            // Convert to DocumentContext for easier manipulation with JsonPath
            DocumentContext documentContext = JsonPath.using(JSON_PATH_CONFIG)
                    .parse(objectMapper.writeValueAsString(result));

            // Process schema and transform data
            processObjectSchema(schema.getFields().getDefinitions().getObjectModel(), taskData, result, documentContext, "$");

            return result;
        } catch (Exception e) {
            throw new TransformationException("Error transforming data: " + e.getMessage(), e);
        }
    }

    private void processObjectSchema(ObjectSchema schema, JsonNode sourceData, ObjectNode targetNode,
                                     DocumentContext documentContext, String currentPath) {
        if (schema == null || schema.getProperties() == null) {
            return;
        }

        schema.getProperties().forEach((propertyName, propertySchema) -> {
            JsonNode valueNode = sourceData.path(propertyName);

            if (valueNode.isMissingNode()) {
                return;
            }

            // Add the value to the primary location
            addValueToTarget(targetNode, propertyName, valueNode, propertySchema);

            // Handle field mapping (additional locations)
            if (propertySchema.getFieldMapping() != null) {
                try {
                    String mappingPath = propertySchema.getFieldMapping();
                    documentContext.set(mappingPath, convertJsonNodeToJavaObject(valueNode));
                } catch (Exception e) {
                    log.error("Error setting field mapping for {}: {}", propertyName, e.getMessage());
                }
            }

            // If this is an object type with nested properties, process recursively
            if ("object".equals(propertySchema.getType()) && propertySchema.getProperties() != null && !valueNode.isMissingNode()) {
                if (!targetNode.has(propertyName)) {
                    targetNode.set(propertyName, objectMapper.createObjectNode());
                }
                processObjectSchema(
                        new ObjectSchema() {{
                            setProperties(propertySchema.getProperties());
                            setType(propertySchema.getType());
                            setValidate(propertySchema.getValidate());
                        }},
                        valueNode,
                        (ObjectNode) targetNode.path(propertyName),
                        documentContext,
                        currentPath + "." + propertyName
                );
            }

            // If this is an array type with object items, process each item
            if ("array".equals(propertySchema.getType()) && "object".equals(propertySchema.getValueType()) &&
                    propertySchema.getProperties() != null && valueNode.isArray()) {

                // Create an ObjectSchema for array items
                ObjectSchema itemSchema = new ObjectSchema();
                itemSchema.setProperties(propertySchema.getProperties());
                itemSchema.setType("object");
                itemSchema.setValidate(propertySchema.getValidate());

                for (int i = 0; i < valueNode.size(); i++) {
                    JsonNode arrayItem = valueNode.get(i);
                    ObjectNode targetItemNode = ((ArrayNode) targetNode.path(propertyName)).addObject();
                    processObjectSchema(
                            itemSchema,
                            arrayItem,
                            targetItemNode,
                            documentContext,
                            currentPath + "." + propertyName + "[" + i + "]"
                    );
                }

                // Handle field mapping for entire array
                if (propertySchema.getFieldMapping() != null) {
                    try {
                        documentContext.set(propertySchema.getFieldMapping(), convertJsonNodeToJavaObject(valueNode));
                    } catch (Exception e) {
                        log.error("Error setting field mapping for array {}: {}", propertyName, e.getMessage());
                    }
                }
            }

            // Perform validation if required
            if (Boolean.TRUE.equals(propertySchema.getValidate())) {
                validateField(propertyName, valueNode, propertySchema);
            }
        });
    }

    private void addValueToTarget(ObjectNode targetNode, String propertyName, JsonNode valueNode, PropertySchema schema) {
        switch (schema.getType()) {
            case "String" -> {
                if (valueNode.isTextual()) {
                    targetNode.put(propertyName, valueNode.asText());
                } else {
                    targetNode.put(propertyName, valueNode.toString());
                }
            }
            case "Int32" -> {
                if (valueNode.isInt()) {
                    targetNode.put(propertyName, valueNode.asInt());
                } else if (valueNode.isTextual()) {
                    try {
                        targetNode.put(propertyName, Integer.parseInt(valueNode.asText()));
                    } catch (NumberFormatException e) {
                        log.warn("Failed to parse Int32 value for {}: {}", propertyName, valueNode.asText());
                        targetNode.put(propertyName, 0);
                    }
                }
            }
            case "LocalDateTime" -> {
                try {
                    LocalDateTime dateTime = valueNode.isTextual()
                            ? LocalDateTime.parse(valueNode.asText())
                            : objectMapper.convertValue(valueNode, LocalDateTime.class);
                    targetNode.put(propertyName, dateTime.toString());
                } catch (Exception e) {
                    log.warn("Failed to parse LocalDateTime for {}: {}", propertyName, valueNode);
                }
            }
            case "object" -> {
                if (!targetNode.has(propertyName)) {
                    targetNode.set(propertyName, objectMapper.createObjectNode());
                }
            }
            case "array" -> {
                if (valueNode.isArray()) {
                    if (!targetNode.has(propertyName)) {
                        targetNode.set(propertyName, objectMapper.createArrayNode());
                    }
                    ArrayNode targetArray = (ArrayNode) targetNode.path(propertyName);

                    // Handle different value types in arrays
                    for (JsonNode item : valueNode) {
                        if ("object".equals(schema.getValueType())) {
                            targetArray.addObject();
                        } else if ("Int32".equals(schema.getValueType())) {
                            targetArray.add(item.asInt());
                        } else if ("String".equals(schema.getValueType())) {
                            targetArray.add(item.asText());
                        } else {
                            targetArray.add(item);
                        }
                    }
                }
            }
            default -> targetNode.set(propertyName, valueNode);
        }
    }

    private void validateField(String propertyName, JsonNode valueNode, PropertySchema schema) {
        // Convert JsonNode to Java object for validation
        Object value = convertJsonNodeToJavaObject(valueNode);
        if (value == null) return;

        // Create validation object based on the schema type
        record ValidationObject(Object value) {}
        ValidationObject validationObject = new ValidationObject(value);

        // Perform validation
        Set<ConstraintViolation<ValidationObject>> violations = validator.validate(validationObject);
        if (!violations.isEmpty()) {
            violations.forEach(violation ->
                    log.warn("Validation failed for field {}: {}", propertyName, violation.getMessage())
            );
        }
    }

    private Object convertJsonNodeToJavaObject(JsonNode node) {
        try {
            if (node.isTextual()) {
                return node.asText();
            } else if (node.isInt()) {
                return node.asInt();
            } else if (node.isBoolean()) {
                return node.asBoolean();
            } else if (node.isArray()) {
                return objectMapper.convertValue(node, List.class);
            } else if (node.isObject()) {
                return objectMapper.convertValue(node, Map.class);
            }
            return objectMapper.convertValue(node, Object.class);
        } catch (Exception e) {
            log.error("Error converting JsonNode to Java object: {}", e.getMessage());
            return null;
        }
    }
}