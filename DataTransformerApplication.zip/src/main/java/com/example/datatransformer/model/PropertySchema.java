package com.example.datatransformer.model;

import lombok.Data;

import java.util.Map;

@Data
public class PropertySchema {
    private String type;
    private Boolean validate;
    private String fieldMapping;
    private Map<String, PropertySchema> properties;
    private String valueType;
}
