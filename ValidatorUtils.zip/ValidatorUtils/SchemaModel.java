package com.example.domainmodel;

import java.util.Map;

/**
 * Schema definition model for validation
 */
public class SchemaModel {
    private String taskName;
    private Fields fields;

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public Fields getFields() {
        return fields;
    }

    public void setFields(Fields fields) {
        this.fields = fields;
    }

    /**
     * Fields container
     */
    public static class Fields {
        private Definitions definitions;

        public Definitions getDefinitions() {
            return definitions;
        }

        public void setDefinitions(Definitions definitions) {
            this.definitions = definitions;
        }
    }

    /**
     * Definitions container
     */
    public static class Definitions {
        private ObjectModel objectModel;

        public ObjectModel getObjectModel() {
            return objectModel;
        }

        public void setObjectModel(ObjectModel objectModel) {
            this.objectModel = objectModel;
        }
    }

    /**
     * Object model container with properties
     */
    public static class ObjectModel {
        private String type;
        private Map<String, PropertyDefinition> properties;

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public Map<String, PropertyDefinition> getProperties() {
            return properties;
        }

        public void setProperties(Map<String, PropertyDefinition> properties) {
            this.properties = properties;
        }
    }

    /**
     * Property definition with type and validation
     */
    public static class PropertyDefinition {
        private String type;
        private Boolean validate;
        private ValidationDefinition validation;
        private String valueType;
        private Map<String, PropertyDefinition> properties;

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public Boolean getValidate() {
            return validate;
        }

        public void setValidate(Boolean validate) {
            this.validate = validate;
        }

        public ValidationDefinition getValidation() {
            return validation;
        }

        public void setValidation(ValidationDefinition validation) {
            this.validation = validation;
        }

        public String getValueType() {
            return valueType;
        }

        public void setValueType(String valueType) {
            this.valueType = valueType;
        }

        public Map<String, PropertyDefinition> getProperties() {
            return properties;
        }

        public void setProperties(Map<String, PropertyDefinition> properties) {
            this.properties = properties;
        }
    }

    /**
     * Validation definition with requirement type and conditions
     */
    public static class ValidationDefinition {
        private String requirementType;
        private String fieldType;
        private String condition;
        private String errorMessage;
        private Map<String, Object> typeValidationParams;

        public String getRequirementType() {
            return requirementType;
        }

        public void setRequirementType(String requirementType) {
            this.requirementType = requirementType;
        }

        public String getFieldType() {
            return fieldType;
        }

        public void setFieldType(String fieldType) {
            this.fieldType = fieldType;
        }

        public String getCondition() {
            return condition;
        }

        public void setCondition(String condition) {
            this.condition = condition;
        }

        public String getErrorMessage() {
            return errorMessage;
        }

        public void setErrorMessage(String errorMessage) {
            this.errorMessage = errorMessage;
        }

        public Map<String, Object> getTypeValidationParams() {
            return typeValidationParams;
        }

        public void setTypeValidationParams(Map<String, Object> typeValidationParams) {
            this.typeValidationParams = typeValidationParams;
        }
    }
}