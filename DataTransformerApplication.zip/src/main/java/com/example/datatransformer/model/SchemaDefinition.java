package com.example.datatransformer.model;

import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document(collection = "schemas")
public class SchemaDefinition {
    private String taskName;
    private String caseModelClassName;
    private String taskModelClassName;
    private Fields fields;

    @Data
    public static class Fields {
        private Definitions definitions;
    }

    @Data
    public static class Definitions {
        private ObjectSchema objectModel;
    }
}
