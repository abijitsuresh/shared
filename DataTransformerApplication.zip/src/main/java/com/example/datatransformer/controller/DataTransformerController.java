package com.example.datatransformer.controller;

import com.example.datatransformer.exception.ErrorResponse;
import com.example.datatransformer.exception.TransformationException;
import com.example.datatransformer.model.TaskRequest;
import com.example.datatransformer.service.DataTransformerService;
import com.example.datatransformer.service.ReverseTransformerService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/transform")
@RequiredArgsConstructor
public class DataTransformerController {
    private final DataTransformerService transformerService;
    private final ReverseTransformerService reverseTransformerService;
    private final ObjectMapper objectMapper;

    @PostMapping("/transform")
    public ResponseEntity<JsonNode> transformData(@RequestBody TaskRequest request) {
        JsonNode result = transformerService.transformData(request);
        return ResponseEntity.ok(result);
    }

    @PostMapping("/reverse-transform")
    public ResponseEntity<TaskRequest> reverseTransformData(@RequestBody JsonNode expandedData) {
        TaskRequest result = reverseTransformerService.reverseTransform(expandedData);
        return ResponseEntity.ok(result);
    }

    @ExceptionHandler(TransformationException.class)
    public ResponseEntity<ErrorResponse> handleTransformationException(TransformationException ex) {
        ErrorResponse errorResponse = new ErrorResponse(ex.getErrorCode(), ex.getMessage());
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
    }
}