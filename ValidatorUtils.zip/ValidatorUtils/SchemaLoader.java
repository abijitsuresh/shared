package com.example.sharedservice.validation;

import com.example.domainmodel.SchemaModel;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * Component to load schema definitions from resources
 */
@Component
public class SchemaLoader {
    private final ResourceLoader resourceLoader;
    private final ObjectMapper objectMapper;
    private final Map<String, SchemaModel> schemaCache = new HashMap<>();

    public SchemaLoader(ResourceLoader resourceLoader, ObjectMapper objectMapper) {
        this.resourceLoader = resourceLoader;
        this.objectMapper = objectMapper;
    }

    /**
     * Load a schema by task name from resources
     *
     * @param taskName The task name to load schema for
     * @return The schema model
     * @throws IOException If the schema cannot be loaded
     */
    public SchemaModel loadSchema(String taskName) throws IOException {
        // Check cache first
        if (schemaCache.containsKey(taskName)) {
            return schemaCache.get(taskName);
        }

        // Load from resources
        String resourcePath = "classpath:schemas/" + taskName + ".json";
        Resource resource = resourceLoader.getResource(resourcePath);
        
        if (!resource.exists()) {
            throw new IOException("Schema not found for task: " + taskName);
        }
        
        try (InputStream is = resource.getInputStream()) {
            SchemaModel schema = objectMapper.readValue(is, SchemaModel.class);
            schemaCache.put(taskName, schema);
            return schema;
        }
    }
    
    /**
     * Convert schema to Map for validation
     *
     * @param schema The schema model
     * @return Map representation of the schema
     */
    public Map<String, Object> convertSchemaToMap(SchemaModel schema) {
        return objectMapper.convertValue(schema, Map.class);
    }
    
    /**
     * Convert request to Map for validation
     *
     * @param request The request object
     * @return Map representation of the request
     */
    public Map<String, Object> convertRequestToMap(Object request) {
        return objectMapper.convertValue(request, Map.class);
    }
}