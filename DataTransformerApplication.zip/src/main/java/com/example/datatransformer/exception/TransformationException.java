package com.example.datatransformer.exception;

import lombok.Getter;

@Getter
public class TransformationException extends RuntimeException {
    private final String errorCode;

    public TransformationException(String message) {
        super(message);
        this.errorCode = "TRANSFORMATION_ERROR";
    }

    public TransformationException(String message, Throwable cause) {
        super(message, cause);
        this.errorCode = "TRANSFORMATION_ERROR";
    }
}

