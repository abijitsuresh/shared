package com.example.datatransformer.model;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class ValidatableField<T> {
    @NotNull(groups = RequiredGroup.class)
    private T value;

    public ValidatableField(T value) {
        this.value = value;
    }

    // Validation groups
    public interface RequiredGroup {}
}
