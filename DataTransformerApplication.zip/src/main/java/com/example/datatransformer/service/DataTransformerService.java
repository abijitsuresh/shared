package com.example.datatransformer.service;

import com.example.datatransformer.exception.TransformationException;
import com.example.datatransformer.exception.ValidationException;
import com.example.datatransformer.model.*;
import com.example.datatransformer.repository.SchemaRepository;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;
import java.util.*;

@Service
@Slf4j
@RequiredArgsConstructor
public class DataTransformerService {
    private final SchemaRepository schemaRepository;
    private final ObjectMapper objectMapper;
    private final Validator validator;

    public JsonNode transformData(TaskRequest request) {
        try {
            // Get schema from MongoDB repository
            SchemaDefinition schema = schemaRepository.findByTaskName(request.getTaskName())
                    .orElseThrow(() -> new TransformationException("Schema not found for task: " + request.getTaskName()));

            // Validate the request against the schema
            Map<String, String> validationErrors = validateRequest(request.getTaskData(), schema.getFields().getDefinitions().getObjectModel());
            if (!validationErrors.isEmpty()) {
                throw new ValidationException("Validation failed", validationErrors);
            }

            // Convert input request to JsonNode
            JsonNode taskData = objectMapper.valueToTree(request.getTaskData());

            // Create output object with taskName
            ObjectNode result = objectMapper.createObjectNode();
            result.put("taskName", request.getTaskName());

            // Process schema and transform primary data
            processObjectSchema(schema.getFields().getDefinitions().getObjectModel(), taskData, result);

            // Process field mappings separately to handle additional paths
            processFieldMappingsRoot(schema.getFields().getDefinitions().getObjectModel(), taskData, result);

            return result;
        } catch (Exception e) {
            throw new TransformationException("Error transforming data: " + e.getMessage(), e);
        }
    }

    private void processObjectSchema(ObjectSchema schema, JsonNode sourceData, ObjectNode targetNode) {
        if (schema == null || schema.getProperties() == null) {
            return;
        }

        schema.getProperties().forEach((propertyName, propertySchema) -> {
            JsonNode valueNode = sourceData.path(propertyName);

            if (valueNode.isMissingNode()) {
                return;
            }

            // Add the value to the primary location
            addValueToTarget(targetNode, propertyName, valueNode, propertySchema);

            // If this is an object type with nested properties, process recursively
            if ("object".equals(propertySchema.getType()) && propertySchema.getProperties() != null && !valueNode.isMissingNode()) {
                if (!targetNode.has(propertyName)) {
                    targetNode.set(propertyName, objectMapper.createObjectNode());
                }
                processObjectSchema(
                        new ObjectSchema() {{
                            setProperties(propertySchema.getProperties());
                            setType(propertySchema.getType());
                            setValidate(propertySchema.getValidate());
                        }},
                        valueNode,
                        (ObjectNode) targetNode.path(propertyName)
                );
            }

            // If this is an array type with object items, process each item
            if ("array".equals(propertySchema.getType()) && "object".equals(propertySchema.getValueType()) &&
                    propertySchema.getProperties() != null && valueNode.isArray()) {

                // Create an ObjectSchema for array items
                ObjectSchema itemSchema = new ObjectSchema();
                itemSchema.setProperties(propertySchema.getProperties());
                itemSchema.setType("object");
                itemSchema.setValidate(propertySchema.getValidate());

                for (int i = 0; i < valueNode.size(); i++) {
                    JsonNode arrayItem = valueNode.get(i);
                    if (targetNode.has(propertyName) && targetNode.get(propertyName).isArray()) {
                        ArrayNode targetArray = (ArrayNode) targetNode.get(propertyName);
                        if (i >= targetArray.size()) {
                            targetArray.addObject();
                        }
                        processObjectSchema(
                                itemSchema,
                                arrayItem,
                                (ObjectNode) targetArray.get(i)
                        );
                    }
                }
            }

            // Perform validation if required
            if (Boolean.TRUE.equals(propertySchema.getValidate())) {
                validateField(propertyName, valueNode, propertySchema);
            }
        });
    }

    private void processFieldMappingsRoot(ObjectSchema schema, JsonNode sourceData, ObjectNode rootNode) {
        if (schema == null || schema.getProperties() == null) {
            return;
        }

        // Process all field mappings at the object level
        processFieldMappings(schema, sourceData, rootNode, rootNode);
    }

    private void processFieldMappings(ObjectSchema schema, JsonNode sourceData, ObjectNode targetNode, ObjectNode rootNode) {
        if (schema == null || schema.getProperties() == null) {
            return;
        }

        schema.getProperties().forEach((propertyName, propertySchema) -> {
            JsonNode valueNode = sourceData.path(propertyName);

            if (valueNode.isMissingNode()) {
                return;
            }

            // Handle field mapping for this property
            if (propertySchema.getFieldMapping() != null) {
                applyFieldMapping(rootNode, propertySchema.getFieldMapping(), valueNode);
            }

            // Process nested objects
            if ("object".equals(propertySchema.getType()) && propertySchema.getProperties() != null && !valueNode.isMissingNode()) {
                if (targetNode.has(propertyName) && targetNode.get(propertyName).isObject()) {
                    processFieldMappings(
                            new ObjectSchema() {{
                                setProperties(propertySchema.getProperties());
                                setType(propertySchema.getType());
                                setValidate(propertySchema.getValidate());
                            }},
                            valueNode,
                            (ObjectNode) targetNode.get(propertyName),
                            rootNode
                    );
                }
            }

            // Process array items
            if ("array".equals(propertySchema.getType()) && valueNode.isArray()) {
                // Apply field mapping for the entire array if specified
                if (propertySchema.getFieldMapping() != null) {
                    applyFieldMapping(rootNode, propertySchema.getFieldMapping(), valueNode);
                }

                // Process individual items if they're objects
                if ("object".equals(propertySchema.getValueType()) && propertySchema.getProperties() != null) {
                    ObjectSchema itemSchema = new ObjectSchema();
                    itemSchema.setProperties(propertySchema.getProperties());
                    itemSchema.setType("object");
                    itemSchema.setValidate(propertySchema.getValidate());

                    if (targetNode.has(propertyName) && targetNode.get(propertyName).isArray()) {
                        ArrayNode targetArray = (ArrayNode) targetNode.get(propertyName);

                        for (int i = 0; i < Math.min(valueNode.size(), targetArray.size()); i++) {
                            if (targetArray.get(i).isObject() && valueNode.get(i).isObject()) {
                                processFieldMappings(
                                        itemSchema,
                                        valueNode.get(i),
                                        (ObjectNode) targetArray.get(i),
                                        rootNode
                                );
                            }
                        }
                    }
                }
            }
        });
    }

    private void applyFieldMapping(ObjectNode rootNode, String fieldMapping, JsonNode valueNode) {
        if (fieldMapping == null || !fieldMapping.startsWith("$.")) {
            return;
        }

        // Remove the $. prefix
        String path = fieldMapping.substring(2);

        if (path.isEmpty()) {
            return;
        }

        // Split the path into parts
        String[] pathParts = path.split("\\.");

        // Create parent objects as needed and set the value
        createPathAndSetValue(rootNode, pathParts, valueNode);
    }

    private void createPathAndSetValue(ObjectNode current, String[] pathParts, JsonNode valueToSet) {
        if (pathParts.length == 1) {
            // We've reached the final part, set the value directly
            setNodeValue(current, pathParts[0], valueToSet);
            return;
        }

        // Get or create the next object in the path
        String part = pathParts[0];
        if (!current.has(part) || !current.get(part).isObject()) {
            current.set(part, objectMapper.createObjectNode());
        }

        // Get the next object and continue
        ObjectNode next = (ObjectNode) current.get(part);

        // Create a new array with the remaining path parts
        String[] remainingParts = Arrays.copyOfRange(pathParts, 1, pathParts.length);

        // Continue with the next part
        createPathAndSetValue(next, remainingParts, valueToSet);
    }

    private void setNodeValue(ObjectNode node, String fieldName, JsonNode value) {
        if (value.isTextual()) {
            node.put(fieldName, value.asText());
        } else if (value.isInt()) {
            node.put(fieldName, value.asInt());
        } else if (value.isLong()) {
            node.put(fieldName, value.asLong());
        } else if (value.isDouble()) {
            node.put(fieldName, value.asDouble());
        } else if (value.isBoolean()) {
            node.put(fieldName, value.asBoolean());
        } else if (value.isArray()) {
            ArrayNode arrayNode = node.putArray(fieldName);
            for (JsonNode item : value) {
                if (item.isObject()) {
                    ObjectNode objNode = arrayNode.addObject();
                    copyJsonNode(item, objNode);
                } else {
                    addValueToArrayNode(arrayNode, item);
                }
            }
        } else if (value.isObject()) {
            ObjectNode objNode;
            if (node.has(fieldName) && node.get(fieldName).isObject()) {
                objNode = (ObjectNode) node.get(fieldName);
            } else {
                objNode = node.putObject(fieldName);
            }
            copyJsonNode(value, objNode);
        } else {
            node.set(fieldName, value);
        }
    }

    private void addValueToArrayNode(ArrayNode arrayNode, JsonNode value) {
        if (value.isTextual()) {
            arrayNode.add(value.asText());
        } else if (value.isInt()) {
            arrayNode.add(value.asInt());
        } else if (value.isLong()) {
            arrayNode.add(value.asLong());
        } else if (value.isDouble()) {
            arrayNode.add(value.asDouble());
        } else if (value.isBoolean()) {
            arrayNode.add(value.asBoolean());
        } else if (value.isObject()) {
            ObjectNode objNode = arrayNode.addObject();
            copyJsonNode(value, objNode);
        } else if (value.isArray()) {
            ArrayNode nestedArray = arrayNode.addArray();
            for (JsonNode item : value) {
                addValueToArrayNode(nestedArray, item);
            }
        } else {
            arrayNode.add(value);
        }
    }

    private void copyJsonNode(JsonNode source, ObjectNode target) {
        Iterator<Map.Entry<String, JsonNode>> fields = source.fields();
        while (fields.hasNext()) {
            Map.Entry<String, JsonNode> field = fields.next();
            setNodeValue(target, field.getKey(), field.getValue());
        }
    }

    private void addValueToTarget(ObjectNode targetNode, String propertyName, JsonNode valueNode, PropertySchema schema) {
        switch (schema.getType()) {
            case "String" -> {
                if (valueNode.isTextual()) {
                    targetNode.put(propertyName, valueNode.asText());
                } else {
                    targetNode.put(propertyName, valueNode.toString());
                }
            }
            case "Int32" -> {
                if (valueNode.isInt()) {
                    targetNode.put(propertyName, valueNode.asInt());
                } else if (valueNode.isTextual()) {
                    try {
                        targetNode.put(propertyName, Integer.parseInt(valueNode.asText()));
                    } catch (NumberFormatException e) {
                        log.warn("Failed to parse Int32 value for {}: {}", propertyName, valueNode.asText());
                        targetNode.put(propertyName, 0);
                    }
                }
            }
            case "LocalDateTime" -> {
                try {
                    LocalDateTime dateTime = valueNode.isTextual()
                            ? LocalDateTime.parse(valueNode.asText())
                            : objectMapper.convertValue(valueNode, LocalDateTime.class);
                    targetNode.put(propertyName, dateTime.toString());
                } catch (Exception e) {
                    log.warn("Failed to parse LocalDateTime for {}: {}", propertyName, valueNode);
                }
            }
            case "object" -> {
                if (!targetNode.has(propertyName)) {
                    targetNode.set(propertyName, objectMapper.createObjectNode());
                }
            }
            case "array" -> {
                if (valueNode.isArray()) {
                    if (!targetNode.has(propertyName)) {
                        targetNode.set(propertyName, objectMapper.createArrayNode());
                    }
                    ArrayNode targetArray = (ArrayNode) targetNode.path(propertyName);

                    // Handle different value types in arrays
                    for (JsonNode item : valueNode) {
                        if ("object".equals(schema.getValueType())) {
                            targetArray.addObject();
                        } else if ("Int32".equals(schema.getValueType())) {
                            targetArray.add(item.isInt() ? item.asInt() : 0);
                        } else if ("String".equals(schema.getValueType())) {
                            targetArray.add(item.isTextual() ? item.asText() : item.toString());
                        } else {
                            targetArray.add(item);
                        }
                    }
                }
            }
            default -> targetNode.set(propertyName, valueNode);
        }
    }

    private void validateField(String propertyName, JsonNode valueNode, PropertySchema schema) {
        // Convert JsonNode to Java object for validation
        Object value = convertJsonNodeToJavaObject(valueNode);
        if (value == null) return;

        // Create validation object based on the schema type
        record ValidationObject(Object value) {}
        ValidationObject validationObject = new ValidationObject(value);

        // Perform validation
        Set<ConstraintViolation<ValidationObject>> violations = validator.validate(validationObject);
        if (!violations.isEmpty()) {
            violations.forEach(violation ->
                    log.warn("Validation failed for field {}: {}", propertyName, violation.getMessage())
            );
        }
    }

    private Object convertJsonNodeToJavaObject(JsonNode node) {
        try {
            if (node.isTextual()) {
                return node.asText();
            } else if (node.isInt()) {
                return node.asInt();
            } else if (node.isBoolean()) {
                return node.asBoolean();
            } else if (node.isArray()) {
                return objectMapper.convertValue(node, List.class);
            } else if (node.isObject()) {
                return objectMapper.convertValue(node, Map.class);
            }
            return objectMapper.convertValue(node, Object.class);
        } catch (Exception e) {
            log.error("Error converting JsonNode to Java object: {}", e.getMessage());
            return null;
        }
    }

    /**
     * Validates the request data against the schema using Jakarta Bean Validation.
     * @param data The request data
     * @param schema The schema to validate against
     * @return A map of validation errors
     */
    private Map<String, String> validateRequest(Map<String, Object> data, ObjectSchema schema) {
        Map<String, String> errors = new HashMap<>();
        validateObject(data, schema, "", errors);
        return errors;
    }

    /**
     * Validates an object against its schema using Jakarta validation.
     */
    private void validateObject(Map<String, Object> data, ObjectSchema schema, String path, Map<String, String> errors) {
        if (schema == null || schema.getProperties() == null) {
            return;
        }

        schema.getProperties().forEach((propertyName, propertySchema) -> {
            String currentPath = path.isEmpty() ? propertyName : path + "." + propertyName;

            // Check if property exists
            Object value = data.get(propertyName);

            // Validate only if validate flag is true
            if (Boolean.TRUE.equals(propertySchema.getValidate())) {
                validateWithJakarta(value, propertySchema.getType(), currentPath, errors);
            }

            // Validate nested objects
            if ("object".equals(propertySchema.getType()) && propertySchema.getProperties() != null && value instanceof Map) {
                @SuppressWarnings("unchecked")
                Map<String, Object> nestedObject = (Map<String, Object>) value;
                validateObject(nestedObject, new ObjectSchema() {{
                    setProperties(propertySchema.getProperties());
                    setType(propertySchema.getType());
                    setValidate(propertySchema.getValidate());
                }}, currentPath, errors);
            }

            // Validate arrays
            if ("array".equals(propertySchema.getType()) && value instanceof List) {
                List<?> list = (List<?>) value;

                if ("object".equals(propertySchema.getValueType()) && propertySchema.getProperties() != null) {
                    for (int i = 0; i < list.size(); i++) {
                        Object item = list.get(i);
                        if (item instanceof Map) {
                            @SuppressWarnings("unchecked")
                            Map<String, Object> objectItem = (Map<String, Object>) item;
                            validateObject(objectItem, new ObjectSchema() {{
                                setProperties(propertySchema.getProperties());
                                setType("object");
                                setValidate(propertySchema.getValidate());
                            }}, currentPath + "[" + i + "]", errors);
                        }
                    }
                } else if (Boolean.TRUE.equals(propertySchema.getValidate())) {
                    // Validate primitive array values
                    for (int i = 0; i < list.size(); i++) {
                        Object item = list.get(i);
                        validateWithJakarta(item, propertySchema.getValueType(), currentPath + "[" + i + "]", errors);
                    }
                }
            }
        });
    }

    /**
     * Validates a value using Jakarta Bean Validation.
     */
    private void validateWithJakarta(Object value, String type, String path, Map<String, String> errors) {
        if (value == null) {
            errors.put(path, "Required field is missing");
            return;
        }

        Set<ConstraintViolation<?>> violations = new HashSet<>();

        switch (type) {
            case "String" -> {
                if (!(value instanceof String)) {
                    errors.put(path, "Expected string value");
                } else {
                    StringField field = new StringField((String) value);
                    violations.addAll(validator.validate(field, StringField.RequiredGroup.class));
                }
            }
            case "Int32" -> {
                if (!(value instanceof Integer) && !(value instanceof Long)) {
                    errors.put(path, "Expected integer value");
                } else {
                    IntegerField field = new IntegerField(value instanceof Long ?
                            ((Long) value).intValue() : (Integer) value);
                    violations.addAll(validator.validate(field, IntegerField.RequiredGroup.class));
                }
            }
            case "LocalDateTime" -> {
                if (!(value instanceof String)) {
                    errors.put(path, "Expected date-time string");
                } else {
                    try {
                        LocalDateTime dateTime = LocalDateTime.parse((String) value);
                        DateTimeField field = new DateTimeField(dateTime);
                        violations.addAll(validator.validate(field, DateTimeField.RequiredGroup.class));
                    } catch (DateTimeParseException e) {
                        errors.put(path, "Invalid date-time format");
                    }
                }
            }
            case "object" -> {
                if (!(value instanceof Map)) {
                    errors.put(path, "Expected object value");
                }
            }
            case "array" -> {
                if (!(value instanceof List)) {
                    errors.put(path, "Expected array value");
                }
            }
        }

        // Add any validation errors
        for (ConstraintViolation<?> violation : violations) {
            errors.put(path, violation.getMessage());
        }
    }
}