package com.example.datatransformer.model;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class IntegerField {
    @NotNull(groups = RequiredGroup.class)
    private Integer value;

    public IntegerField(Integer value) {
        this.value = value;
    }

    // Validation groups
    public interface RequiredGroup {}
}
