package com.example.datatransformer.service;

import com.example.datatransformer.exception.TransformationException;
import com.example.datatransformer.model.ObjectSchema;
import com.example.datatransformer.model.PropertySchema;
import com.example.datatransformer.model.SchemaDefinition;
import com.example.datatransformer.model.TaskRequest;
import com.example.datatransformer.repository.SchemaRepository;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Service
@Slf4j
@RequiredArgsConstructor
public class DataTransformerService1 {
    private final SchemaRepository schemaRepository;
    private final ObjectMapper objectMapper;
    private final Validator validator;

    public JsonNode transformData(TaskRequest request) {
        try {
            // Get schema from MongoDB repository
            SchemaDefinition schema = schemaRepository.findByTaskName(request.getTaskName())
                    .orElseThrow(() -> new TransformationException("Schema not found for task: " + request.getTaskName()));

            // Convert input request to JsonNode
            JsonNode taskData = objectMapper.valueToTree(request.getTaskData());

            // Create output object with taskName
            ObjectNode result = objectMapper.createObjectNode();
            result.put("taskName", request.getTaskName());

            // Process schema and transform data
            processObjectSchema(schema.getFields().getDefinitions().getObjectModel(), taskData, result);

            // Process field mappings after the main processing
            processFieldMappings(schema.getFields().getDefinitions().getObjectModel(), taskData, result);

            return result;
        } catch (Exception e) {
            throw new TransformationException("Error transforming data: " + e.getMessage(), e);
        }
    }

    private void processObjectSchema(ObjectSchema schema, JsonNode sourceData, ObjectNode targetNode) {
        if (schema == null || schema.getProperties() == null) {
            return;
        }

        schema.getProperties().forEach((propertyName, propertySchema) -> {
            JsonNode valueNode = sourceData.path(propertyName);

            if (valueNode.isMissingNode()) {
                return;
            }

            // Add the value to the primary location
            addValueToTarget(targetNode, propertyName, valueNode, propertySchema);

            // If this is an object type with nested properties, process recursively
            if ("object".equals(propertySchema.getType()) && propertySchema.getProperties() != null && !valueNode.isMissingNode()) {
                if (!targetNode.has(propertyName)) {
                    targetNode.set(propertyName, objectMapper.createObjectNode());
                }
                processObjectSchema(
                        new ObjectSchema() {{
                            setProperties(propertySchema.getProperties());
                            setType(propertySchema.getType());
                            setValidate(propertySchema.getValidate());
                        }},
                        valueNode,
                        (ObjectNode) targetNode.path(propertyName)
                );
            }

            // If this is an array type with object items, process each item
            if ("array".equals(propertySchema.getType()) && "object".equals(propertySchema.getValueType()) &&
                    propertySchema.getProperties() != null && valueNode.isArray()) {

                // Create an ObjectSchema for array items
                ObjectSchema itemSchema = new ObjectSchema();
                itemSchema.setProperties(propertySchema.getProperties());
                itemSchema.setType("object");
                itemSchema.setValidate(propertySchema.getValidate());

                for (int i = 0; i < valueNode.size(); i++) {
                    JsonNode arrayItem = valueNode.get(i);
                    ObjectNode targetItemNode = ((ArrayNode) targetNode.path(propertyName)).addObject();
                    processObjectSchema(
                            itemSchema,
                            arrayItem,
                            targetItemNode
                    );
                }
            }

            // Perform validation if required
            if (Boolean.TRUE.equals(propertySchema.getValidate())) {
                validateField(propertyName, valueNode, propertySchema);
            }
        });
    }

    private void processFieldMappings(ObjectSchema schema, JsonNode sourceData, ObjectNode targetNode) {
        if (schema == null || schema.getProperties() == null) {
            return;
        }

        schema.getProperties().forEach((propertyName, propertySchema) -> {
            JsonNode valueNode = sourceData.path(propertyName);

            if (valueNode.isMissingNode()) {
                return;
            }

            // Handle field mapping (additional locations)
            if (propertySchema.getFieldMapping() != null) {
                String[] pathParts = propertySchema.getFieldMapping().replace("$.", "").split("\\.");
                createNestedPath(targetNode, pathParts, 0, valueNode);
            }

            // Recursively process nested objects
            if ("object".equals(propertySchema.getType()) && propertySchema.getProperties() != null && !valueNode.isMissingNode()) {
                if (propertySchema.getFieldMapping() != null) {
                    String[] pathParts = propertySchema.getFieldMapping().replace("$.", "").split("\\.");
                    ObjectNode nestedTarget = createNestedObjectPath(targetNode, pathParts, 0);
                    copyJsonNode(valueNode, nestedTarget);
                }

                // Continue processing nested properties
                processFieldMappings(
                        new ObjectSchema() {{
                            setProperties(propertySchema.getProperties());
                            setType(propertySchema.getType());
                            setValidate(propertySchema.getValidate());
                        }},
                        valueNode,
                        targetNode.has(propertyName) ? (ObjectNode) targetNode.get(propertyName) : null
                );
            }

            // Process array items
            if ("array".equals(propertySchema.getType()) && "object".equals(propertySchema.getValueType()) &&
                    propertySchema.getProperties() != null && valueNode.isArray()) {

                // Handle field mapping for entire array
                if (propertySchema.getFieldMapping() != null) {
                    String[] pathParts = propertySchema.getFieldMapping().replace("$.", "").split("\\.");
                    ArrayNode arrayNode = targetNode.putArray(pathParts[pathParts.length - 1]);

                    for (JsonNode item : valueNode) {
                        ObjectNode newItem = arrayNode.addObject();
                        copyJsonNode(item, newItem);
                    }
                }

                // Create schema for array items
                ObjectSchema itemSchema = new ObjectSchema();
                itemSchema.setProperties(propertySchema.getProperties());
                itemSchema.setType("object");
                itemSchema.setValidate(propertySchema.getValidate());

                // Process each array item
                for (int i = 0; i < valueNode.size(); i++) {
                    JsonNode arrayItem = valueNode.get(i);
                    if (targetNode.has(propertyName) && targetNode.get(propertyName).isArray() &&
                            i < targetNode.get(propertyName).size()) {
                        processFieldMappings(
                                itemSchema,
                                arrayItem,
                                (ObjectNode) targetNode.get(propertyName).get(i)
                        );
                    }
                }
            }
        });
    }

    private void createNestedPath(ObjectNode rootNode, String[] pathParts, int index, JsonNode valueToSet) {
        if (index >= pathParts.length - 1) {
            // We've reached the final part, set the value
            setNodeValue(rootNode, pathParts[index], valueToSet);
            return;
        }

        // Create or get the nested object
        String currentPart = pathParts[index];
        if (!rootNode.has(currentPart)) {
            rootNode.set(currentPart, objectMapper.createObjectNode());
        }

        // Move to the next level
        if (rootNode.get(currentPart).isObject()) {
            createNestedPath((ObjectNode) rootNode.get(currentPart), pathParts, index + 1, valueToSet);
        }
    }

    private ObjectNode createNestedObjectPath(ObjectNode rootNode, String[] pathParts, int index) {
        if (index >= pathParts.length - 1) {
            // We've reached the final part
            if (!rootNode.has(pathParts[index])) {
                rootNode.set(pathParts[index], objectMapper.createObjectNode());
            }
            return (ObjectNode) rootNode.get(pathParts[index]);
        }

        // Create or get the nested object
        String currentPart = pathParts[index];
        if (!rootNode.has(currentPart)) {
            rootNode.set(currentPart, objectMapper.createObjectNode());
        }

        // Move to the next level
        return createNestedObjectPath((ObjectNode) rootNode.get(currentPart), pathParts, index + 1);
    }

    private void setNodeValue(ObjectNode node, String fieldName, JsonNode value) {
        if (value.isTextual()) {
            node.put(fieldName, value.asText());
        } else if (value.isInt()) {
            node.put(fieldName, value.asInt());
        } else if (value.isLong()) {
            node.put(fieldName, value.asLong());
        } else if (value.isDouble()) {
            node.put(fieldName, value.asDouble());
        } else if (value.isBoolean()) {
            node.put(fieldName, value.asBoolean());
        } else if (value.isArray()) {
            ArrayNode arrayNode = node.putArray(fieldName);
            for (JsonNode item : value) {
                if (item.isObject()) {
                    ObjectNode objNode = arrayNode.addObject();
                    copyJsonNode(item, objNode);
                } else {
                    addValueToArrayNode(arrayNode, item);
                }
            }
        } else if (value.isObject()) {
            ObjectNode objNode;
            if (node.has(fieldName) && node.get(fieldName).isObject()) {
                objNode = (ObjectNode) node.get(fieldName);
            } else {
                objNode = node.putObject(fieldName);
            }
            copyJsonNode(value, objNode);
        } else {
            node.set(fieldName, value);
        }
    }

    private void addValueToArrayNode(ArrayNode arrayNode, JsonNode value) {
        if (value.isTextual()) {
            arrayNode.add(value.asText());
        } else if (value.isInt()) {
            arrayNode.add(value.asInt());
        } else if (value.isLong()) {
            arrayNode.add(value.asLong());
        } else if (value.isDouble()) {
            arrayNode.add(value.asDouble());
        } else if (value.isBoolean()) {
            arrayNode.add(value.asBoolean());
        } else if (value.isObject()) {
            ObjectNode objNode = arrayNode.addObject();
            copyJsonNode(value, objNode);
        } else if (value.isArray()) {
            ArrayNode nestedArray = arrayNode.addArray();
            for (JsonNode item : value) {
                addValueToArrayNode(nestedArray, item);
            }
        } else {
            arrayNode.add(value);
        }
    }

    private void copyJsonNode(JsonNode source, ObjectNode target) {
        Iterator<Map.Entry<String, JsonNode>> fields = source.fields();
        while (fields.hasNext()) {
            Map.Entry<String, JsonNode> field = fields.next();
            setNodeValue(target, field.getKey(), field.getValue());
        }
    }

    private void addValueToTarget(ObjectNode targetNode, String propertyName, JsonNode valueNode, PropertySchema schema) {
        switch (schema.getType()) {
            case "String" -> {
                if (valueNode.isTextual()) {
                    targetNode.put(propertyName, valueNode.asText());
                } else {
                    targetNode.put(propertyName, valueNode.toString());
                }
            }
            case "Int32" -> {
                if (valueNode.isInt()) {
                    targetNode.put(propertyName, valueNode.asInt());
                } else if (valueNode.isTextual()) {
                    try {
                        targetNode.put(propertyName, Integer.parseInt(valueNode.asText()));
                    } catch (NumberFormatException e) {
                        log.warn("Failed to parse Int32 value for {}: {}", propertyName, valueNode.asText());
                        targetNode.put(propertyName, 0);
                    }
                }
            }
            case "LocalDateTime" -> {
                try {
                    LocalDateTime dateTime = valueNode.isTextual()
                            ? LocalDateTime.parse(valueNode.asText())
                            : objectMapper.convertValue(valueNode, LocalDateTime.class);
                    targetNode.put(propertyName, dateTime.toString());
                } catch (Exception e) {
                    log.warn("Failed to parse LocalDateTime for {}: {}", propertyName, valueNode);
                }
            }
            case "object" -> {
                if (!targetNode.has(propertyName)) {
                    targetNode.set(propertyName, objectMapper.createObjectNode());
                }
            }
            case "array" -> {
                if (valueNode.isArray()) {
                    if (!targetNode.has(propertyName)) {
                        targetNode.set(propertyName, objectMapper.createArrayNode());
                    }
                    ArrayNode targetArray = (ArrayNode) targetNode.path(propertyName);

                    // Handle different value types in arrays
                    for (JsonNode item : valueNode) {
                        if ("object".equals(schema.getValueType())) {
                            targetArray.addObject();
                        } else if ("Int32".equals(schema.getValueType())) {
                            targetArray.add(item.asInt());
                        } else if ("String".equals(schema.getValueType())) {
                            targetArray.add(item.asText());
                        } else {
                            targetArray.add(item);
                        }
                    }
                }
            }
            default -> targetNode.set(propertyName, valueNode);
        }
    }

    private void validateField(String propertyName, JsonNode valueNode, PropertySchema schema) {
        // Convert JsonNode to Java object for validation
        Object value = convertJsonNodeToJavaObject(valueNode);
        if (value == null) return;

        // Create validation object based on the schema type
        record ValidationObject(Object value) {
        }
        ValidationObject validationObject = new ValidationObject(value);

        // Perform validation
        Set<ConstraintViolation<ValidationObject>> violations = validator.validate(validationObject);
        if (!violations.isEmpty()) {
            violations.forEach(violation ->
                    log.warn("Validation failed for field {}: {}", propertyName, violation.getMessage())
            );
        }
    }

    private Object convertJsonNodeToJavaObject(JsonNode node) {
        try {
            if (node.isTextual()) {
                return node.asText();
            } else if (node.isInt()) {
                return node.asInt();
            } else if (node.isBoolean()) {
                return node.asBoolean();
            } else if (node.isArray()) {
                return objectMapper.convertValue(node, List.class);
            } else if (node.isObject()) {
                return objectMapper.convertValue(node, Map.class);
            }
            return objectMapper.convertValue(node, Object.class);
        } catch (Exception e) {
            log.error("Error converting JsonNode to Java object: {}", e.getMessage());
            return null;
        }
    }
}