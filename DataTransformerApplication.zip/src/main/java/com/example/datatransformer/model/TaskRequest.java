package com.example.datatransformer.model;

import lombok.Data;

import java.util.Map;

@Data
public class TaskRequest {
    private String taskName;
    private Map<String, Object> taskData;
}
