package com.example.datatransformer.example;

import com.example.datatransformer.model.TaskRequest;
import com.example.datatransformer.service.ReverseTransformerService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

/**
 * Example demonstrating the reverse transformation process.
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class ReverseTransformerExample implements CommandLineRunner {
    private final ReverseTransformerService reverseTransformerService;
    private final ObjectMapper objectMapper;

    @Override
    public void run(String... args) {
        try {
            // Example 1: Reverse transform task1
            JsonNode input1 = createTask1InputData();
            log.info("Input data for task1: {}", objectMapper.writeValueAsString(input1));

            TaskRequest output1 = reverseTransformerService.reverseTransform(input1);
            log.info("Output data for task1: {}", objectMapper.writeValueAsString(output1));

            // Example 2: Reverse transform task2
            JsonNode input2 = createTask2InputData();
            log.info("Input data for task2: {}", objectMapper.writeValueAsString(input2));

            TaskRequest output2 = reverseTransformerService.reverseTransform(input2);
            log.info("Output data for task2: {}", objectMapper.writeValueAsString(output2));

        } catch (Exception e) {
            log.error("Error in example: {}", e.getMessage(), e);
        }
    }

    private JsonNode createTask1InputData() {
        ObjectNode input = objectMapper.createObjectNode();
        input.put("taskName", "task1");
        input.put("age", 35);

        ObjectNode personalInfo = input.putObject("personalInfo");
        personalInfo.put("name", "John");

        ObjectNode status = input.putObject("status");
        status.put("anotherRequestedDate", "2024-07-03T10:15:30.365384");

        return input;
    }

    private JsonNode createTask2InputData() {
        ObjectNode input = objectMapper.createObjectNode();
        input.put("taskName", "task2");
        input.put("name", "John");
        input.put("age", 33);

        // Add request reasons
        input.putArray("requestReasons").add(1).add(2).add(3);

        // Add job types
        ObjectNode jobType1 = objectMapper.createObjectNode();
        jobType1.put("jobTypeCode", 23);
        jobType1.put("jobTypeValue", "teacher");

        ObjectNode jobType2 = objectMapper.createObjectNode();
        jobType2.put("jobTypeCode", 24);
        jobType2.put("jobTypeValue", "preacher");

        input.putArray("jobTypes").add(jobType1).add(jobType2);

        // Add registered address
        ObjectNode registeredAddress = input.putObject("registeredAddress");
        registeredAddress.put("zipCode", "28260");
        registeredAddress.put("country", "US");
        registeredAddress.put("city", "Charlotte");
        registeredAddress.put("stateOrProvince", "NC");
        registeredAddress.put("line1", "2636 Main St");
        registeredAddress.put("line2", "Suite 523");

        // Add formed address
        ObjectNode formedAddress = input.putObject("formedAddress");
        formedAddress.put("country", "USA");

        // Add copied job types (same as job types)
        input.putArray("copiedJobTypes").add(objectMapper.valueToTree(jobType1)).add(objectMapper.valueToTree(jobType2));

        return input;
    }
}