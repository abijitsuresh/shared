package com.example.datatransformer.service;

import com.example.datatransformer.exception.TransformationException;
import com.example.datatransformer.model.ObjectSchema;
import com.example.datatransformer.model.PropertySchema;
import com.example.datatransformer.model.SchemaDefinition;
import com.example.datatransformer.model.TaskRequest;
import com.example.datatransformer.repository.SchemaRepository;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Iterator;
import java.util.Map;

@Service
@Slf4j
@RequiredArgsConstructor
public class ReverseTransformerService {
    private final SchemaRepository schemaRepository;
    private final ObjectMapper objectMapper;

    /**
     * Reverse transforms the data based on schema mappings.
     * Takes a transformed object and creates a compact TaskRequest object.
     *
     * @param expandedData The expanded data to reverse transform
     * @return TaskRequest object with the original structure
     */
    public TaskRequest reverseTransform(JsonNode expandedData) {
        try {
            String taskName = expandedData.path("taskName").asText();
            if (taskName.isEmpty()) {
                throw new TransformationException("taskName is required in the input data");
            }

            // Get schema from MongoDB repository
            SchemaDefinition schema = schemaRepository.findByTaskName(taskName)
                    .orElseThrow(() -> new TransformationException("Schema not found for task: " + taskName));

            // Create output TaskRequest
            TaskRequest result = new TaskRequest();
            result.setTaskName(taskName);

            // Create taskData object
            ObjectNode taskData = objectMapper.createObjectNode();

            // Process schema and build the compact taskData
            reverseTransformObject(schema.getFields().getDefinitions().getObjectModel(), expandedData, taskData);

            // Set the taskData
            result.setTaskData(objectMapper.convertValue(taskData, Map.class));

            return result;
        } catch (Exception e) {
            throw new TransformationException("Error reverse transforming data: " + e.getMessage(), e);
        }
    }

    /**
     * Reverse transforms an object based on schema.
     */
    private void reverseTransformObject(ObjectSchema schema, JsonNode sourceData, ObjectNode targetNode) {
        if (schema == null || schema.getProperties() == null) {
            return;
        }

        // Process each property in the schema
        schema.getProperties().forEach((propertyName, propertySchema) -> {
            if ("object".equals(propertySchema.getType())) {
                // Handle nested objects
                processNestedObject(propertyName, propertySchema, sourceData, targetNode);
            } else if ("array".equals(propertySchema.getType())) {
                // Handle arrays
                processArray(propertyName, propertySchema, sourceData, targetNode);
            } else {
                // Handle primitive values
                processPrimitive(propertyName, propertySchema, sourceData, targetNode);
            }
        });
    }

    /**
     * Process a nested object property
     */
    private void processNestedObject(String propertyName, PropertySchema propertySchema, JsonNode sourceData, ObjectNode targetNode) {
        if (propertySchema.getProperties() == null) {
            return;
        }

        // Create target object node
        ObjectNode nestedTarget = targetNode.putObject(propertyName);

        // Find the source object if it exists directly
        final JsonNode directObject = sourceData.path(propertyName);

        // Check field mapping for the entire object - make it final for lambda use
        final JsonNode mappedObject;
        if (propertySchema.getFieldMapping() != null) {
            String mappingPath = propertySchema.getFieldMapping().replace("$.", "");
            JsonNode tempMappedObject = findValueByPath(sourceData, mappingPath);

            // If mapped object is found, copy its properties
            if (tempMappedObject != null && !tempMappedObject.isMissingNode() && tempMappedObject.isObject()) {
                copyJsonNodeFields(tempMappedObject, nestedTarget);
            }
            mappedObject = tempMappedObject;
        } else {
            mappedObject = null;
        }

        // Process each nested property
        propertySchema.getProperties().forEach((nestedPropName, nestedPropSchema) -> {
            // For nested objects
            if ("object".equals(nestedPropSchema.getType())) {
                processNestedObject(nestedPropName, nestedPropSchema, sourceData, nestedTarget);
            }
            // For arrays
            else if ("array".equals(nestedPropSchema.getType())) {
                processArray(nestedPropName, nestedPropSchema, sourceData, nestedTarget);
            }
            // For primitive properties - check direct or mapped values
            else {
                // First check in direct object (top priority)
                if (!directObject.isMissingNode() && !directObject.path(nestedPropName).isMissingNode()) {
                    addValueByType(nestedTarget, nestedPropName, directObject.get(nestedPropName), nestedPropSchema);
                }
                // Then check field mapping for this specific property
                else if (nestedPropSchema.getFieldMapping() != null) {
                    String mappingPath = nestedPropSchema.getFieldMapping().replace("$.", "");
                    JsonNode mappedValue = findValueByPath(sourceData, mappingPath);

                    if (mappedValue != null && !mappedValue.isMissingNode()) {
                        addValueByType(nestedTarget, nestedPropName, mappedValue, nestedPropSchema);
                    }
                }
                // Finally check in mapped object for this property
                else if (mappedObject != null && !mappedObject.isMissingNode() &&
                        !mappedObject.path(nestedPropName).isMissingNode()) {
                    addValueByType(nestedTarget, nestedPropName, mappedObject.get(nestedPropName), nestedPropSchema);
                }
            }
        });
    }

    /**
     * Process an array property
     */
    private void processArray(String propertyName, PropertySchema propertySchema, JsonNode sourceData, ObjectNode targetNode) {
        // Look for direct array in source
        JsonNode directArray = sourceData.path(propertyName);

        // Also check if it might be found through field mapping
        JsonNode mappedArray = null;
        if (propertySchema.getFieldMapping() != null) {
            String mappingPath = propertySchema.getFieldMapping().replace("$.", "");
            mappedArray = findValueByPath(sourceData, mappingPath);
        }

        // Use either the direct array or the mapped array if available
        JsonNode sourceArray = !directArray.isMissingNode() ? directArray :
                (mappedArray != null && !mappedArray.isMissingNode() ? mappedArray : null);

        if (sourceArray != null && sourceArray.isArray()) {
            // Create array in target
            ArrayNode targetArray = targetNode.putArray(propertyName);

            // Process each array item
            for (JsonNode item : sourceArray) {
                if ("object".equals(propertySchema.getValueType()) && propertySchema.getProperties() != null) {
                    // Add object to array
                    ObjectNode targetItem = targetArray.addObject();

                    // For each property in the item schema
                    propertySchema.getProperties().forEach((itemPropName, itemPropSchema) -> {
                        if (item.has(itemPropName)) {
                            JsonNode itemValue = item.get(itemPropName);
                            addValueByType(targetItem, itemPropName, itemValue, itemPropSchema);
                        }
                    });
                } else {
                    // For primitive array items, add directly
                    addValueToArrayNode(targetArray, item);
                }
            }
        }
    }

    /**
     * Process a primitive property
     */
    private void processPrimitive(String propertyName, PropertySchema propertySchema, JsonNode sourceData, ObjectNode targetNode) {
        // Check if value exists directly
        JsonNode directValue = sourceData.path(propertyName);

        // Check if value exists in field mapping
        JsonNode mappedValue = null;
        if (propertySchema.getFieldMapping() != null) {
            String mappingPath = propertySchema.getFieldMapping().replace("$.", "");
            mappedValue = findValueByPath(sourceData, mappingPath);
        }

        // Use direct value if exists, otherwise use mapped value
        JsonNode valueToUse = !directValue.isMissingNode() ? directValue :
                (mappedValue != null && !mappedValue.isMissingNode() ? mappedValue : null);

        // Add value to target if found
        if (valueToUse != null && !valueToUse.isMissingNode()) {
            addValueByType(targetNode, propertyName, valueToUse, propertySchema);
        }
    }

    /**
     * Copies all fields from source JsonNode to target ObjectNode
     */
    private void copyJsonNodeFields(JsonNode source, ObjectNode target) {
        if (source == null || !source.isObject()) {
            return;
        }

        Iterator<Map.Entry<String, JsonNode>> fields = source.fields();
        while (fields.hasNext()) {
            Map.Entry<String, JsonNode> entry = fields.next();
            target.set(entry.getKey(), entry.getValue());
        }
    }

    /**
     * Add a value to the target node based on its type from the schema
     */
    private void addValueByType(ObjectNode targetNode, String propertyName, JsonNode valueNode, PropertySchema schema) {
        if (valueNode == null || valueNode.isMissingNode()) {
            return;
        }

        switch (schema.getType()) {
            case "String" -> {
                if (valueNode.isTextual()) {
                    targetNode.put(propertyName, valueNode.asText());
                } else {
                    targetNode.put(propertyName, valueNode.toString());
                }
            }
            case "Int32" -> {
                if (valueNode.isInt()) {
                    targetNode.put(propertyName, valueNode.asInt());
                } else if (valueNode.isTextual()) {
                    try {
                        targetNode.put(propertyName, Integer.parseInt(valueNode.asText()));
                    } catch (NumberFormatException e) {
                        log.warn("Failed to parse Int32 value for {}: {}", propertyName, valueNode.asText());
                    }
                }
            }
            case "LocalDateTime" -> {
                if (valueNode.isTextual()) {
                    targetNode.put(propertyName, valueNode.asText());
                }
            }
            case "object" -> {
                if (valueNode.isObject()) {
                    ObjectNode objNode = targetNode.putObject(propertyName);
                    copyJsonNodeFields(valueNode, objNode);
                }
            }
            case "array" -> {
                if (valueNode.isArray()) {
                    ArrayNode arrayNode = targetNode.putArray(propertyName);
                    for (JsonNode item : valueNode) {
                        addValueToArrayNode(arrayNode, item);
                    }
                }
            }
            default -> targetNode.set(propertyName, valueNode);
        }
    }

    /**
     * Finds a value in a JSON node by path.
     */
    private JsonNode findValueByPath(JsonNode node, String path) {
        if (path == null || path.isEmpty()) {
            return node;
        }

        String[] parts = path.split("\\.");
        JsonNode current = node;

        for (String part : parts) {
            current = current.path(part);
            if (current.isMissingNode()) {
                return current;
            }
        }

        return current;
    }

    /**
     * Adds a value to an array node.
     */
    private void addValueToArrayNode(ArrayNode arrayNode, JsonNode value) {
        if (value.isTextual()) {
            arrayNode.add(value.asText());
        } else if (value.isInt()) {
            arrayNode.add(value.asInt());
        } else if (value.isLong()) {
            arrayNode.add(value.asLong());
        } else if (value.isDouble()) {
            arrayNode.add(value.asDouble());
        } else if (value.isBoolean()) {
            arrayNode.add(value.asBoolean());
        } else if (value.isObject()) {
            ObjectNode objNode = arrayNode.addObject();
            copyJsonNodeFields(value, objNode);
        } else {
            arrayNode.add(value);
        }
    }
}