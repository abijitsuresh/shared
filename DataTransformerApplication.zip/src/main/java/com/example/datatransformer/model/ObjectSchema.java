package com.example.datatransformer.model;

import lombok.Data;

import java.util.Map;

@Data
public class ObjectSchema {
    private String type;
    private Boolean validate;
    private Map<String, PropertySchema> properties;
    private String valueType;
    private String fieldMapping;
}