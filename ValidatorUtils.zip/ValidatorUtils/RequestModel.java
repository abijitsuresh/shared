package com.example.domainmodel;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Domain model class for task requests
 */
public class RequestModel {
    private String taskName;
    private TaskData taskData;

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public TaskData getTaskData() {
        return taskData;
    }

    public void setTaskData(TaskData taskData) {
        this.taskData = taskData;
    }

    /**
     * Task data container class
     */
    public static class TaskData {
        private String name;
        private PersonalInfo personalInfo;
        private List<Integer> requestReasons;
        private List<JobType> jobTypes;
        private List<Comment> comments;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public PersonalInfo getPersonalInfo() {
            return personalInfo;
        }

        public void setPersonalInfo(PersonalInfo personalInfo) {
            this.personalInfo = personalInfo;
        }

        public List<Integer> getRequestReasons() {
            return requestReasons;
        }

        public void setRequestReasons(List<Integer> requestReasons) {
            this.requestReasons = requestReasons;
        }

        public List<JobType> getJobTypes() {
            return jobTypes;
        }

        public void setJobTypes(List<JobType> jobTypes) {
            this.jobTypes = jobTypes;
        }

        public List<Comment> getComments() {
            return comments;
        }

        public void setComments(List<Comment> comments) {
            this.comments = comments;
        }
    }

    /**
     * Personal information container
     */
    public static class PersonalInfo {
        private Integer age;
        private Address address;

        public Integer getAge() {
            return age;
        }

        public void setAge(Integer age) {
            this.age = age;
        }

        public Address getAddress() {
            return address;
        }

        public void setAddress(Address address) {
            this.address = address;
        }
    }

    /**
     * Address information container
     */
    public static class Address {
        private String line1;
        private String line2;
        private String city;
        private String state;
        private String stateOrProvince;
        private String country;
        private String zipCode;

        public String getLine1() {
            return line1;
        }

        public void setLine1(String line1) {
            this.line1 = line1;
        }

        public String getLine2() {
            return line2;
        }

        public void setLine2(String line2) {
            this.line2 = line2;
        }

        public String getCity() {
            return city;
        }

        public void setCity(String city) {
            this.city = city;
        }

        public String getState() {
            return state;
        }

        public void setState(String state) {
            this.state = state;
        }

        public String getStateOrProvince() {
            return stateOrProvince;
        }

        public void setStateOrProvince(String stateOrProvince) {
            this.stateOrProvince = stateOrProvince;
        }

        public String getCountry() {
            return country;
        }

        public void setCountry(String country) {
            this.country = country;
        }

        public String getZipCode() {
            return zipCode;
        }

        public void setZipCode(String zipCode) {
            this.zipCode = zipCode;
        }
    }

    /**
     * Job type container
     */
    public static class JobType {
        private Integer jobTypeCode;
        private String jobTypeValue;

        public Integer getJobTypeCode() {
            return jobTypeCode;
        }

        public void setJobTypeCode(Integer jobTypeCode) {
            this.jobTypeCode = jobTypeCode;
        }

        public String getJobTypeValue() {
            return jobTypeValue;
        }

        public void setJobTypeValue(String jobTypeValue) {
            this.jobTypeValue = jobTypeValue;
        }
    }

    /**
     * Comment container
     */
    public static class Comment {
        private String comment;
        private LocalDateTime commentDate;
        private String commentBy;

        public String getComment() {
            return comment;
        }

        public void setComment(String comment) {
            this.comment = comment;
        }

        public LocalDateTime getCommentDate() {
            return commentDate;
        }

        public void setCommentDate(LocalDateTime commentDate) {
            this.commentDate = commentDate;
        }

        public String getCommentBy() {
            return commentBy;
        }

        public void setCommentBy(String commentBy) {
            this.commentBy = commentBy;
        }
    }
}