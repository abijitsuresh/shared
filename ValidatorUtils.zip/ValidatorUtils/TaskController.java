package com.example.application.controller;

import com.example.application.service.TaskService;
import com.example.domainmodel.RequestModel;
import com.example.sharedservice.validation.ValidationService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.List;

/**
 * Controller for handling task requests
 */
@RestController
@RequestMapping("/api/tasks")
public class TaskController {
    private final ValidationService validationService;
    private final TaskService taskService;

    public TaskController(ValidationService validationService, TaskService taskService) {
        this.validationService = validationService;
        this.taskService = taskService;
    }

    /**
     * Process a task request after validation
     *
     * @param request The request model
     * @return Response with result or validation errors
     */
    @PostMapping("/process")
    public ResponseEntity<?> processTask(@RequestBody RequestModel request) {
        try {
            // Validate the request
            List<String> validationErrors = validationService.validateRequest(request);
            
            // If there are validation errors, return them
            if (!validationErrors.isEmpty()) {
                return ResponseEntity.badRequest().body(validationErrors);
            }
            
            // Process the request with the service
            String result = taskService.processTask(request);
            
            return ResponseEntity.ok(result);
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error processing request: " + e.getMessage());
        }
    }
}