package com.example.sharedservice.validation;

import com.example.domainmodel.RequestModel;
import com.example.domainmodel.SchemaModel;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * Service for validating requests against schemas
 */
@Service
public class ValidationService {
    private final SchemaLoader schemaLoader;

    public ValidationService(SchemaLoader schemaLoader) {
        this.schemaLoader = schemaLoader;
    }

    /**
     * Validate a request against its schema
     *
     * @param request The request to validate
     * @return A list of validation errors, empty if validation passes
     * @throws IOException If the schema cannot be loaded
     */
    public List<String> validateRequest(RequestModel request) throws IOException {
        if (request == null || request.getTaskName() == null) {
            throw new IllegalArgumentException("Request or task name is null");
        }
        
        // Load the schema for this task
        SchemaModel schema = schemaLoader.loadSchema(request.getTaskName());
        
        // Convert both to maps for validation
        Map<String, Object> requestMap = schemaLoader.convertRequestToMap(request);
        Map<String, Object> schemaMap = schemaLoader.convertSchemaToMap(schema);
        
        // Validate using the utility
        return RequestValidatorUtils.validate(requestMap, schemaMap);
    }
}