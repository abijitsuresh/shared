@RestController
@RequestMapping("/api/cases")
class CaseController {
    
    private final DataTransformationService transformationService;
    private final MongoTemplate mongoTemplate;
    
    @Autowired
    public CaseController(DataTransformationService transformationService, MongoTemplate mongoTemplate) {
        this.transformationService = transformationService;
        this.mongoTemplate = mongoTemplate;
    }
    
    @PostMapping
    public ResponseEntity<?> createCase(@RequestBody Map<String, Object> requestData) {
        try {
            CaseModel caseModel = transformationService.transformAndSave(requestData);
            return ResponseEntity.ok(caseModel);
        } catch (ValidationException e) {
            return ResponseEntity.badRequest().body(Map.of("error", "Validation failed", "details", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(Map.of("error", e.getMessage()));
        }
    }
    
    @GetMapping("/{taskId}")
    public ResponseEntity<?> getCase(@PathVariable String taskId) {
        try {
            CaseModel caseModel = mongoTemplate.findOne(
                    Query.query(Criteria.where("taskId").is(taskId)),
                    CaseModel.class,
                    "cases"
            );
            
            if (caseModel == null) {
                return ResponseEntity.notFound().build();
            }
            
            Map<String, Object> originalFormat = transformationService.convertToOriginalFormat(caseModel);
            return ResponseEntity.ok(originalFormat);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(Map.of("error", e.getMessage()));
        }
    }
}