package com.example.datatransformer.example;

import com.example.datatransformer.model.TaskRequest;
import com.example.datatransformer.service.DataTransformerService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * Example demonstrating how to use the data transformer service.
 * This is just for demonstration purposes and not required for the actual implementation.
 */
@Component
@RequiredArgsConstructor
@Slf4j
@Profile("demo")
public class TransformerExample implements CommandLineRunner {
    private final DataTransformerService transformerService;
    private final ObjectMapper objectMapper;

    @Override
    public void run(String... args) {
        try {
            // Example of task1 transformation
            TaskRequest task1Request = new TaskRequest();
            task1Request.setTaskName("task1");
            task1Request.setTaskData(Map.of(
                    "name", "John",
                    "age", 35,
                    "requestedDate", "2024-07-03T10:15:30.365384"
            ));

            log.info("Task1 transformation request: {}", objectMapper.writeValueAsString(task1Request));
            JsonNode task1Result = transformerService.transformData(task1Request);
            log.info("Task1 transformation result: {}", objectMapper.writeValueAsString(task1Result));

            // Example of task2 transformation
            TaskRequest task2Request = new TaskRequest();
            task2Request.setTaskName("task2");
            // Create a more complex object with nested structures
            Map<String, Object> task2Data = createTask2Data();
            task2Request.setTaskData(task2Data);

            log.info("Task2 transformation request: {}", objectMapper.writeValueAsString(task2Request));
            JsonNode task2Result = transformerService.transformData(task2Request);
            log.info("Task2 transformation result: {}", objectMapper.writeValueAsString(task2Result));
        } catch (Exception e) {
            log.error("Error in example: {}", e.getMessage(), e);
        }
    }

    private Map<String, Object> createTask2Data() {
        // Create a nested object structure similar to the example in requirements
        Map<String, Object> addressData = Map.of(
                "line1", "2636 Main St",
                "line2", "Suite 523",
                "city", "Charlotte",
                "stateOrProvince", "NC",
                "country", "US",
                "zipCode", "28260"
        );

        Map<String, Object> personalInfo = Map.of(
                "age", 33,
                "address", addressData
        );

        Map<String, Object> jobType1 = Map.of(
                "jobTypeCode", 23,
                "jobTypeValue", "teacher"
        );

        Map<String, Object> jobType2 = Map.of(
                "jobTypeCode", 24,
                "jobTypeValue", "preacher"
        );

        return Map.of(
                "name", "John",
                "personalInfo", personalInfo,
                "requestReasons", List.of(1, 2, 3),
                "jobTypes", List.of(jobType1, jobType2)
        );
    }
}