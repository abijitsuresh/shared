package com.example.datatransformer.exception;

import lombok.Getter;

import java.util.Map;

/**
 * Exception thrown when validation fails.
 */
@Getter
public class ValidationException extends RuntimeException {
    private final Map<String, String> errors;
    private final String errorCode;

    public ValidationException(String message, Map<String, String> errors) {
        super(message);
        this.errors = errors;
        this.errorCode = "VALIDATION_ERROR";
    }
}