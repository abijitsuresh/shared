package com.example.datatransformer.model;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class DateTimeField {
    @NotNull(groups = RequiredGroup.class)
    private LocalDateTime value;

    public DateTimeField(LocalDateTime value) {
        this.value = value;
    }

    // Validation groups
    public interface RequiredGroup {}
}
